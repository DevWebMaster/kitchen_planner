<?php
defined('BASEPATH') OR exit('No direct script access allowed');




$lang['l_e_api_p_code_require'] = 'Customer code required!';
$lang['l_e_api_branch_require'] = 'Branch code required!';
$lang['l_e_api_key_require'] = 'API key required!';



$lang['l_e_api_key_require'] = 'Customer code or Api key required!';
$lang['l_e_api_key'] = 'Invalid customer code and Api key!';

$lang['l_e_hash_key'] = 'Hash key required!';
$lang['l_e_hash_check'] = 'Hash does not match!';




?>