<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['l_e_job_error'] = 'Job not registered!';



?>