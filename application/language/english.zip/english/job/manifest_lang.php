<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['l_e_manisfest_file_error'] = 'Unalbe to create or open file!';



?>