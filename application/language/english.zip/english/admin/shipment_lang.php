<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['l_title'] = 'Shipment - Create Manifest';
$lang['l_detail_title'] = 'Shipment - View Shipment Detail';

$lang['l_generate_manifest'] = 'Generate Manifest';
$lang['l_shipmet_form_title'] = 'Generate Manifest Form';


$lang['l_label_code'] = 'Shipment Code';
$lang['l_label_facility_id'] = 'Facility';
$lang['l_label_name_en'] = 'Name';
$lang['l_label_mawb'] = 'Mawb';
$lang['l_label_away_prefix'] = 'Away prefix';
$lang['l_label_awb_serialno'] = 'AWB Serial No.';
$lang['l_label_airport_origin'] = 'Airport Origin';
$lang['l_label_airport_arrival'] = 'Airport Arrival';
$lang['l_label_import_air_carrier_code'] = 'Import Air Carrier Code';
$lang['l_label_flight_number'] = 'Flight Number';
$lang['l_label_schedule_arrival_date'] = 'Schedule arrival date';
$lang['l_label_schedule_departure_date'] = 'Schedule departure date';
$lang['l_label_cargo_terminal_operator'] = 'Cargo Terminal Operator';  
$lang['l_label_permit_proceed_dest_airport'] = 'Permit Proceed Destination Airport'; 
$lang['l_label_eta_permit_proceed_dest_airport'] = 'ETA permit proceed destination Airport';
$lang['l_label_customer_id'] = 'Customer ID'; 
$lang['l_label_branch_code'] = 'Branch code'; 
$lang['l_label_shipment_status_id'] = 'Shipment Status'; 




$lang['l_exclude_tracking_no'] = 'Exclude the following tracking number';

$lang['l_exclude_selected_shipment'] = 'Selected shipment no.';

$lang['l_create_manifest_task'] = 'Create manifest task';

$lang['l_shipment_id'] = 'Shipment ID';
$lang['l_shipment_name_en'] = 'Shipment Name';
?>