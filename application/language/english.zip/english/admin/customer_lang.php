<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['l_title'] = 'Customer Manager';
//$lang['l_branch_title'] = 'Branch';
//$lang['l_levels_title'] = 'Levels';
$lang['l_customers_summary'] = 'Customer Summary';

$lang['l_customers_summary_total'] = 'Total Customers';
$lang['l_active_customers'] = 'Active Customers';
$lang['l_inactive_active_customers'] = 'Inactive Customers';
$lang['l_customers_summary_active'] = 'Active Contacts';
$lang['l_customers_summary_inactive'] = 'Inactive Contacts';
$lang['l_customers_summary_logged_in_today'] = 'Contacts Logged In Today';
$lang['l_customer_details'] = 'Customer Details';
$lang['l_billing_shipping_1'] = 'Billing & Shipping 1';
$lang['l_billing_shipping_2'] = 'Billing & Shipping 2';

// Customer Details Tab
$lang['l_customer_code'] = 'Customer Code';
$lang['l_customer_name'] = 'Customer Name';
$lang['l_addr1'] = 'Address 1';
$lang['l_addr2'] = 'Address 2';
$lang['l_street'] = 'Street';
$lang['l_city'] = 'City';
$lang['l_state'] = 'State';
$lang['l_country'] = 'Country';
$lang['l_zip'] = 'Zip Code';
$lang['l_website'] = 'Website';
$lang['l_level'] = 'Level';
$lang['l_status'] = 'Status';
$lang['l_dropdown_non_selected_tex'] = 'Nothing selected';
$lang['l_billing_address_1'] = 'Billing Address 1';
$lang['l_shipping_address_1'] = 'Shipping Address 1';
$lang['l_billing_address_2'] = 'Billing Address 2';
$lang['l_shipping_address_2'] = 'Shipping Address 2';
$lang['l_customer_billing_same_as_profile'] = 'Same as Customer Info';
$lang['l_customer_billing_copy'] = 'Copy Billing Address';
$lang['l_submit'] = 'Save';
$lang['l_'] = '';
$lang['l_'] = '';

?>