<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['l_postage_title'] = 'Finances - Postage Fees';

$lang['l_postage_effective_date'] = 'Effective Date';
$lang['l_postage_rate_type'] = 'Rate Type';
$lang['l_postage_customer_level'] = 'Customer Level';



?>