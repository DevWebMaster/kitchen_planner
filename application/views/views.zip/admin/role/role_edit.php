  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <div class="card card-default">
        <div class="card-header">
          <div class="d-inline-block">
              <h3 class="card-title"> <i class="fa fa-pencil"></i>
              &nbsp; <?= trans('l_edit_role') ?> </h3>
          </div>
          <div class="d-inline-block float-right">
            <a href="<?= base_url('admin/role'); ?>" class="btn btn-success"><i class="fa fa-list"></i> <?= trans('l_role_list') ?></a>
            <a href="<?= base_url('admin/role/add'); ?>" class="btn btn-success"><i class="fa fa-plus"></i> <?= trans('l_add_new_role') ?></a>
          </div>
        </div>
        <div class="card-body">
   
           <!-- For Messages -->
            <?php $this->load->view('admin/includes/_messages.php') ?>
           
            <?php echo form_open(base_url('admin/role/edit/'.$role['id']), 'class="form-horizontal"' )?> 
              <div class="form-group">
                <label for="username" class="col-md-2 control-label"><?= trans('l_title') ?></label>

                <div class="col-md-12">
                  <input type="text" name="title" value="<?= $role['title']; ?>" class="form-control" id="title" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="firstname" class="col-md-2 control-label"><?= trans('l_description') ?></label>

                <div class="col-md-12">
                  <input type="text" name="description" value="<?= $role['description']; ?>" class="form-control" id="description" placeholder="">
                </div>
              </div>

              <div class="form-group">
                <label for="role" class="col-md-2 control-label"><?= trans('l_rec_status') ?></label>

                <div class="col-md-12">
                  <select name="rec_status" class="form-control">
                    <option value=""><?= trans('select_status') ?></option>
                    <option value="1" <?= ($role['rec_status'] == 1)?'selected': '' ?> >Active</option>
                    <option value="0" <?= ($role['rec_status'] == 0)?'selected': '' ?>>Deactive</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-12">
                  <input type="submit" name="submit" value="<?= trans('l_update_role') ?>" class="btn btn-primary pull-right">
                </div>
              </div>
            <?php echo form_close(); ?>
        </div>
          <!-- /.box-body -->
      </div>  
    </section> 
  </div>