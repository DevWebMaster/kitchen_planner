<!-- DataTables -->
<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/datatables/dataTables.bootstrap4.css"> 

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <section class="content">
    <!-- For Messages -->
    <?php $this->load->view('admin/includes/_messages.php') ?>
    <div class="card">
      <div class="card-header">
        <div class="d-inline-block">
          <h3 class="card-title"><i class="fa fa-list"></i>&nbsp; <?= trans('l_title') ?></h3>
        </div>
      
        <div class="d-inline-block float-right">
          <?php /* if($this->rbac->check_operation_permission(9001)): ?>
            <a href="<?= base_url('admin/admin/add'); ?>" class="btn btn-success"><i class="fa fa-plus"></i> <?= trans('add_new_user') ?></a>
          <?php endif; */ ?>
        </div>
      </div>
    </div>
    <div class="card">
        <div class="card-body table-responsive">
          <?php echo $content ?>
        </div>
    </div>
  </section>  
</div>
