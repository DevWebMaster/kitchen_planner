<!-- DataTables -->
<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/datatables/dataTables.bootstrap4.css"> 

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <section class="content">
    <!-- For Messages -->
    <?php $this->load->view('admin/includes/_messages.php') ?>
    <div class="card">
      <div class="card-header">
        <div class="d-inline-block">
          <h3 class="card-title"><i class="fa fa-list"></i>&nbsp; <?= trans('l_shipmet_form_title') ?></h3>
        </div>
        <div class="d-inline-block float-right">
        </div>
      </div>
    </div>
    <div class="card">
      
      <div class="card-body ">
        <div class="row">
            <div class="col-12">
                <div class="card card-default ">
                  <div class="card-header bg-brand">
                    <h3 class="card-title"><?= trans('l_create_manifest_task'); ?></h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <!--form role="form" name="shipmentform" action="<?= base_url('admin/shipment/generate');?>" method="POST"-->
                  <?php echo form_open(base_url('admin/shipment/generate'), 'id=shipmentform"');  ?>
                    <div class="card-body">
                      <div class="row">  
                          <div class="col-6"><b><?= trans('l_exclude_selected_shipment'); ?></b><br/>
                              
                              
                              <?php foreach ($shipments as $shipment){ ?>
                                
                                <div class="pt-1 pb-1"><input type="checkbox" checked name="selected_shipment_id[]"> <?= $shipment['name_en']; ?>
                                <span class="label  bg-brand pb-1 pl-2 pr-2" data-toggle='collapse' data-target='#collapsediv<?= $shipment['shipment_id']?>'><small><i class="fa fa-search"></i>View</small></span> 
                                  <div id='collapsediv<?= $shipment['shipment_id']?>' class='collapse div<?= $shipment['shipment_id']?>'>
                                    <div class="p-3">
                                     <?= trans('l_shipment_id').': '. shipment['shipment_id'];?><br>
                                     <?= trans('l_shipment_name_en').': '.shipment['name_en'];?><br>
                                     Facility:
                                     Custromer Info:
                                    </div>
                                  </div>

                                </div>

                              <?php } ?>   
                          </div>  
                          <div class="col-6">  
                              <div class="form-group">
                                <label><?= trans('l_exclude_tracking_no'); ?>:</label>
                                <textarea name="trackno" class="form-control" rows="12" placeholder="Enter exclude tracking no..."></textarea>
                              </div>
                          </div><!-- end of col-6 -->
                      </div><!-- end of col-6 -->
                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                      <button type="submit" class="btn btn-info float-right">Submit</button>
                    </div>
                  <?php echo form_close(); ?>   
                </div>
            </div><!-- end of column -->
        </div>
      </div>
    </div>
  </section>  
</div>
<script type="text/javascript">


//$(".cb").click(function(){  

function checkselect(identifier,id)
{
  //$("#"+identifier+id)

  var select_status =  $("#"+identifier+id).attr('data-selected');  
 
  if(select_status == 0)
   {
      
      $("#"+identifier+id).removeClass('btn-default');
      $("#"+identifier+id).addClass('btn-danger');  
      $("#"+identifier+id).attr('data-selected','1');
      $("#"+identifier+id).find($(".fa")).toggleClass('fa-square').toggleClass('fa-check-square');
      
      // add to session 
      $.ajax({
            type: 'GET',
            url:'<?= site_url() ?>admin/shipment/add_session',
            data: { item: $("#"+identifier+id).attr('data-shipment-id') },
            success:function(response) {
                               
            }
        });
   }
  else 
   {  $("#"+identifier+id).removeClass('btn-danger');
      $("#"+identifier+id).addClass('btn-default');  
      $("#"+identifier+id).attr('data-selected','0');
      $("#"+identifier+id).find($(".fa")).toggleClass('fa-square').toggleClass('fa-check-square');

      // remove from session
       $.ajax({
            type: 'GET',
            url:'<?= site_url() ?>admin/shipment/remove_session',
            data: { item: $("#"+identifier+id).attr('data-shipment-id') },
            success:function(response) {
                
            }
        });
   }

}
//});



jQuery(document).on("xcrudafterrequest",function(event,container){
   // highlight_button();
});



</script>
