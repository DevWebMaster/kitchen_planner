<!-- DataTables -->
<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/datatables/dataTables.bootstrap4.css"> 
<!-- Script -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="<?= base_url()?>vendor/phpformbuilder/plugin/bootstrap-select/dist/js/bootstrap-select.min.js"></script>

<!-- CSS -->
<link href='select2/dist/css/select2.min.css' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="<?= base_url()?>vendor/phpformbuilder/plugin/bootstrap-select/dist/css/bootstrap-select.min.css">

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <section class="content">
    <div class="card">
      <div class="card-body table-responsive"> 
          <?php echo form_open(base_url('admin/Shipment/filterSearch'), 'class="form-horizontal"');  ?> 
        <div class="row">
          <div class="col-md-3">
              <label>Customer Name:</label>
		<select id="position-applying-for-s1" name="customer_name" class="select2 form-control" data-placeholder="Choose one ..." required>
			<option value="null" >All</option>
                            <?php foreach ($customer_list as $customer) {
                                $chkboxId = $customer['id'];
                                echo '<option value="'.$customer['id'].'" >'.$customer['name'].'</option>';
                            }
                            ?>                        
		</select>
          </div>
          <div class="col-md-3">
              <label>Shipment Code:</label>
		<select id="position-applying-for-s3" name="shipment_code" class="form-control select2-allow-clear select2-hidden-accessible" data-placeholder="Choose one ..." required>
			<option value="null" >All</option>
                            <?php foreach ($shipment_code_list as $code) {
                                $chkboxId = $code[code];
                                echo '<option value="'.$code['shipment_id'].'" >'.$code['info'].'</option>';
                            }
                            ?>                        
		</select>
          </div>

        </div>
            <div class="form-group">
                <div class="col-md-12">
                    <input type="submit" name="submit" value="<?= trans('l_search') ?>" class="btn btn-primary pull-right">
                </div>
            </div>
          
        <?php echo form_close(); ?>
      </div>
    </div>  


    <div class="card">
      <div class="card-body table-responsive">
          <?php echo form_open(base_url('admin/shipment/generate'), 'id="user_search"');  ?> 

          <!-- checkbox -->
                  <div class="form-group">
                      <label>Select Shipment</label>

                        <div class="card-body">
                            <?php foreach ($shipments as $shipment) {
                                $temp = base_url("admin/shipment/checkbox_OnClick");
                                $chkboxId = $shipment['shipment_id'];
                            ?>
                            <div class="form-check">
                                
                                <?php 
                                    echo '<input name="selected_shipment_id[]" value="'.$chkboxId.'" type="checkbox" class="form-check-input" id="exampleCheck1" >';
                                ?>
                                <label class="form-check-label" for="<?php echo $chkboxId ?>"><?php echo $shipment['name_en']?></label>
                            </div>                            
                            <?php } ?>
                        </div>
                  </div>

                  <!-- Select multiple-->
                  <div class="form-group">
                    <label>Select Excluded Tracking Number</label>
                    <textarea name="trackno" style="height:300px" class="form-control" aria-label="With textarea"></textarea>
                  </div>
            <div class="form-group">
                <div class="col-md-12">
                    <input type="submit" name="submit" value="Generate" class="btn btn-primary pull-right">
                </div>
            </div>                  
            <?php echo form_close(); ?>                  
      </div>
      <!-- /.box-body -->
    </div>
  </section>  
</div>

<!-- bootstrap datepicker -->
<!-- datepicker -->
<script src="<?= base_url() ?>assets/plugins/datepicker/bootstrap-datepicker.js"></script>
<script>
  $('.datepicker').datepicker({
    autoclose: true
  });
</script>
<!-- DataTables -->
<script src="<?= base_url() ?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/dataTables.bootstrap4.js"></script>
<script>
  //---------------------------------------------------
  var table = $('#na_datatable').DataTable( {
    "processing": true,
    "serverSide": false,
    "ajax": "<?=base_url('admin/example/advance_datatable_json')?>",
    "order": [[4,'desc']],
    "columnDefs": [
    { "targets": 0, "name": "id", 'searchable':true, 'orderable':true},
    { "targets": 1, "name": "username", 'searchable':true, 'orderable':true},
    { "targets": 2, "name": "email", 'searchable':true, 'orderable':true},
    { "targets": 3, "name": "mobile_no", 'searchable':true, 'orderable':true},
    { "targets": 4, "name": "created_at", 'searchable':false, 'orderable':false},
    { "targets": 5, "name": "is_active", 'searchable':true, 'orderable':true},
    ]
  });

  //---------------------------------------------------
  function user_filter()
  {
      
    var _form = $("#user_search").serialize();
    $.ajax({
      data: _form,
      type: 'post',
      url:'<?php echo base_url("admin/shipment/checkbox_OnClick"); ?>',
      async: true,
      success: function(response){
          //alert('success');
          var data = JSON.parse(response);
          alert(data[0].tracking_no);
            $('#parcelid').val(data[0].tracking_no);

        //table.ajax.reload( null, false );
      }
    });
  }
</script>
  <!-- Scripts for this page -->
  <script type="text/javascript">
 $(document).ready(function(){

     $(document).on('click','.chkbox',function(){
      //var id=this.value;
    alert('result from controller');
        


        var id = $('#prod').val();
         $.ajax({
                type:'POST',
                url:'<?php echo base_url("admin/shipment/generate"); ?>',
                data:{'id':id},
                success:function(data){
                    alert('success');
                    $('#resultdiv').html(data);
                }
            });
   });

 });      
 $(document).ready(function(){
 
  // Initialize select2
  $("#selUser").select2();

  // Read selected option
  $('#but_read').click(function(){
    var username = $('#selUser option:selected').text();
    var userid = $('#selUser').val();

    $('#result').html("id : " + userid + ", name : " + username);

  });
});
  </script>



