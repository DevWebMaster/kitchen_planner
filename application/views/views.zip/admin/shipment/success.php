
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $title ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo base_url('admin/shipment')?>">Back</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="error-page">

        <div class="error-content">
          <h3><i class="fa fa-success text-danger"></i>Generate Manifest file successfully.</h3>
          <h3><i class="fa fa-success text-danger"></i>Manifest detail shown as below.</h3>

          <?php 
                echo '<p>manifest_id => '.$job_manifest_info['manifest_id'].'</p>';
                echo '<p>facility_id => '.$job_manifest_info['facility_id'].'</p>';
                echo '<p>schedule_at => '.$job_manifest_info['schedule_at'].'</p>';
                echo '<p>parcel_total => '.$job_manifest_info['parcel_total'].'</p>';
                echo '<p>send_flag => '.$job_manifest_info['send_flag'].'</p>';
                echo '<p>send_log => '.$job_manifest_info['send_log'].'</p>';
          
          
          ?>

        </div>
      </div>
      <!-- /.error-page -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->