<!-- DataTables -->
<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/datatables/dataTables.bootstrap4.css"> 

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <section class="content">
    <!-- For Messages -->
    <?php $this->load->view('admin/includes/_messages.php') ?>
    <div class="card">
      <div class="card-header">
        <div class="d-inline-block">
          <h3 class="card-title"><i class="fa fa-list"></i>&nbsp; <?= trans('l_title') ?></h3>
        </div>
        <div class="d-inline-block float-right">
       
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body table-responsive">
        <?php echo $content; ?>
      </div>
     
    </div>
  </section>  
</div>
<script type="text/javascript">


//$(".cb").click(function(){  

function checkselect(identifier,id)
{
  //$("#"+identifier+id)

  var select_status =  $("#"+identifier+id).attr('data-selected');  
 
  if(select_status == 0)
   {
      
      $("#"+identifier+id).removeClass('btn-default');
      $("#"+identifier+id).addClass('btn-danger');  
      $("#"+identifier+id).attr('data-selected','1');
      $("#"+identifier+id).find($(".fa")).toggleClass('fa-square').toggleClass('fa-check-square');
      
      // add to session 
      $.ajax({
            type: 'GET',
            url:'<?= site_url() ?>admin/shipment/add_session',
            data: { item: $("#"+identifier+id).attr('data-shipment-id') },
            success:function(response) {
                               
            }
        });
   }
  else 
   {  $("#"+identifier+id).removeClass('btn-danger');
      $("#"+identifier+id).addClass('btn-default');  
      $("#"+identifier+id).attr('data-selected','0');
      $("#"+identifier+id).find($(".fa")).toggleClass('fa-square').toggleClass('fa-check-square');

      // remove from session
       $.ajax({
            type: 'GET',
            url:'<?= site_url() ?>admin/shipment/remove_session',
            data: { item: $("#"+identifier+id).attr('data-shipment-id') },
            success:function(response) {
                
            }
        });
   }

}
//});



jQuery(document).on("xcrudafterrequest",function(event,container){
   // highlight_button();
});



</script>
