  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
          <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">
              
            <div class="card">
                <div class="card-header">
                  <h4 class="bold">
                     #<?php echo $client['id'] . ' ' . $client['name']; ?>
                  </h4>
                </div>
            </div>
              
            <div class="card">
                <div class="card-body p-0">
                <ul class="nav nav-pills flex-column">
                    <?php foreach($customer_tabs as $key => $panel){?>
                        <li class="<?php if($panel['slug'] == 'profile'){echo 'active ';} ?>customer_tab_<?php echo $panel['slug']; ?>">
                            <a data-group="<?php echo $panel['slug']; ?>" href="<?php 
                            echo base_url('admin/customer/customer/'.$client['id'].'?group='.$panel['slug']); ?>">
                            <?php if(!empty($panel['fa_icon'])){ ?>
                                <i class="<?php echo $panel['fa_icon']; ?> menu-icon" aria-hidden="true"></i>
                            <?php } ?>
                            <?php echo $panel['name']; ?>
                            </a>
                        </li>
                    <?php } ?>
                    
                </ul>                    
                </div>
            </div>
            
            <!-- /.card -->
          </div>
            <?php //$this->load->view('admin/customer/groups/branch'); ?>
            <?php $this->load->view((isset($tab) ? $tab['view'] : 'admin/clients/groups/profile')); ?>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
  </div>
