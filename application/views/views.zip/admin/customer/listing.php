<!-- DataTables -->
<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/datatables/dataTables.bootstrap4.css"> 

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <section class="content">
    <!-- For Messages -->
    <?php $this->load->view('admin/includes/_messages.php') ?>
    <div class="card">
      <div class="card-header">
        <div class="d-inline-block">
          <h3 class="card-title"><i class="fa fa-list"></i>&nbsp; <?= trans('l_title') ?></h3>
        </div>
        <div class="d-inline-block float-right">
        </div>
          
      </div>
    </div>
    <div class="card">
    <div class="row mbot15">
                     <div class="col-md-12">
                        <h4 class="no-margin"><?php echo trans('l_customers_summary'); ?></h4>
                     </div> 
                     <div class="col-md-2 col-xs-6 border-right">
                        <h3 class="bold"><?php echo $total_customer; ?></h3>
                        <span class="text-dark"><?php echo trans('l_customers_summary_total'); ?></span>
                     </div>
                     <div class="col-md-2 col-xs-6 border-right">
                        <h3 class="bold"><?php echo $total_customer_active; ?></h3>
                        <span class="text-dark"><?php echo trans('l_active_customers'); ?></span>
                     </div>
                     <div class="col-md-2 col-xs-6 border-right">
                        <h3 class="bold"><?php echo $total_customer_inactive; ?></h3>
                        <span class="text-dark"><?php echo trans('l_inactive_active_customers'); ?></span>
                     </div>
<!--                     <div class="col-md-2 col-xs-6 border-right">
                        <h3 class="bold"><?php echo '34'; ?></h3>
                        <span class="text-dark"><?php echo trans('l_customers_summary_active'); ?></span>
                     </div>
                     <div class="col-md-2 col-xs-6 border-right">
                        <h3 class="bold"><?php echo '34'; ?></h3>
                        <span class="text-dark"><?php echo trans('l_customers_summary_inactive'); ?></span>
                     </div>
                     <div class="col-md-2 col-xs-6 border-right">
                        <h3 class="bold"><?php echo '34'; ?></h3>
                        <span class="text-dark"><?php echo trans('l_customers_summary_logged_in_today'); ?></span>
                     </div>-->
    </div>
        </div>
    <div class="card">
      <div class="card-body table-responsive">
        <?php echo $content ?>
<!--        <div class="row"><div class="col-12 "><a class="btn btn-info float-right" id="btn_action_generate_manifest" href="<?= $this->uri->rsegment(1) ?>/customer/1"><?= 'View'?></a></div></div>-->
      </div>
    </div>
  </section>  
</div>
