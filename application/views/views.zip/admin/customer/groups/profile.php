<div class="col-md-9">
            <div class="card">
                <div class="card-header p-2">
                    <h4 class="customer-profile-group-heading"><?php echo 'Profile'; ?></h4>
                    </hr>
                </div>
              <div class="card-header p-2">
                  

                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#customer_details" data-toggle="tab"><?php echo trans('l_customer_details'); ?></a></li>
                  <li class="nav-item"><a class="nav-link" href="#billing1" data-toggle="tab"><?php echo trans('l_billing_shipping_1'); ?></a></li>
                  <li class="nav-item"><a class="nav-link" href="#billing2" data-toggle="tab"><?php echo trans('l_billing_shipping_2'); ?></a></li>
                </ul>
              </div><!-- /.card-header -->
                         <!-- For Messages -->
            <?php $this->load->view('admin/includes/_messages.php') ?>

              <?php echo form_open(base_url($this->uri->uri_string()),array('class'=>'client-form','autocomplete'=>'off')); ?>
              <div class="card-body">
                <div class="tab-content">
                  <div class="active tab-pane" id="customer_details">
                    <!--<form class="form-horizontal">-->
                        <div class="row">
                            <div class="col-md-6">
                                <?php $value=( isset($client) ? $client['customer_code'] : ''); ?>
                                <?php echo render_input( 'customer_code', 'l_customer_code',$value); ?>
                                <?php $value=( isset($client) ? $client['name'] : ''); ?>
                                <?php echo render_input( 'name', 'l_customer_name',$value); ?>
                                <?php $value=( isset($client) ? $client['website'] : ''); ?>
                                <?php echo render_input( 'website', 'l_website',$value); ?>
                                <?php
                                    $selected =( isset($client) ? $client['customer_level_id'] : 1);
                                    echo render_select( 'customer_level_id',$levels,array( 'id',array( 'title')), 'l_level',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php
                                    $selected =( isset($client) ? $client['customer_status_id'] : 1);
                                    echo render_select( 'customer_status_id',$status,array( 'id',array( 'title')), 'l_status',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                           </div>
                           <div class="col-md-6">
                              <?php $value=( isset($client) ? $client['addr1'] : ''); ?>
                              <?php echo render_textarea( 'addr1', 'l_addr1',$value); ?>
                              <?php $value=( isset($client) ? $client['addr2'] : ''); ?>
                              <?php echo render_textarea( 'addr2', 'l_addr2',$value); ?>
                              <?php $value=( isset($client) ? $client['zipcode'] : ''); ?>
                              <?php echo render_input( 'zipcode', 'l_zip',$value); ?>

                                <?php 
                                $selected =( isset($client) ? $client['country_id'] : 1);
                                echo render_select( 'country_id',$countries,array( 'id',array( 'name')), 'l_country',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = 'state_id'; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$states,array( 'id',array( 'name')), 'l_state',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = 'city_id'; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$cities,array( 'id',array( 'name')), 'l_city',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                           </div>
                        </div>
                    <!--</form>-->
                  </div>                    
                  <!-- /.tab-pane -->

                  <div class="tab-pane" id="billing1">
                    <!--<form class="form-horizontal">-->
                        <div class="row">
                            <div class="col-md-6">
                        <h4 class="no-mtop"><?php echo trans('l_billing_address_1'); ?> <a href="#" class="pull-right billing-same-as-customer-1"><small class="font-medium-xs"><?php //echo trans('l_customer_billing_same_as_profile'); ?></small></a></h4>
                        <hr />
                                <?php 
                                    $addrType = 'billing';
                                    $addrNum = '1';
                                ?>
                                <?php $name = $addrType.'_street_'.$addrNum; $value=( isset($client) ? $client[$name] : ''); ?>
                                <?php echo render_textarea( $name, 'l_street',$value); ?>
                                <?php $name = $addrType.'_zipcode_'.$addrNum; $value=( isset($client) ? $client[$name] : ''); ?>
                                <?php echo render_input( $name, 'l_zip',$value); ?>
                                <?php 
                                $name = $addrType.'_country_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$countries,array( 'id',array( 'name')), 'l_country',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = $addrType.'_state_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$billing_states_1,array( 'id',array( 'name')), 'l_state',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = $addrType.'_city_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$billing_cities_1,array( 'id',array( 'name')), 'l_city',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                           </div>
                           <div class="col-md-6">
                                <h4 class="no-mtop">
                                   <!--<i class="fa fa-question-circle" data-toggle="tooltip" data-title="<?php //echo trans('l_customer_shipping_address_notice'); ?>"></i>-->
                                   <?php echo trans('l_shipping_address_1'); ?> <a href="#" class="pull-right customer-copy-billing-address-1"><small class="font-medium-xs"><?php //echo trans('l_customer_billing_copy'); ?></small></a>
                                </h4>
                                <hr />
                                <?php 
                                    $addrType = 'shipping';
                                    $addrNum = '1';
                                ?>
                                <?php $name = $addrType.'_street_'.$addrNum; $value=( isset($client) ? $client[$name] : ''); ?>
                                <?php echo render_textarea( $name, 'l_street',$value); ?>
                                <?php $name = $addrType.'_zipcode_'.$addrNum; $value=( isset($client) ? $client[$name] : ''); ?>
                                <?php echo render_input( $name, 'l_zip',$value); ?>
                                <?php 
                                $name = $addrType.'_country_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$countries,array( 'id',array( 'name')), 'l_country',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = $addrType.'_state_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$shipping_states_1,array( 'id',array( 'name')), 'l_state',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = $addrType.'_city_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$shipping_cities_1,array( 'id',array( 'name')), 'l_city',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                           </div>
                        </div>
                    <!--</form>-->
                  </div>
                  <div class="tab-pane" id="billing2">
                    <!--<form class="form-horizontal">-->
                        <div class="row">
                            <div class="col-md-6">
                        <h4 class="no-mtop"><?php echo trans('l_billing_address_2'); ?> <a href="#" class="pull-right billing-same-as-customer-2"><small class="font-medium-xs"><?php //echo trans('l_customer_billing_same_as_profile'); ?></small></a></h4>
                        <hr />
                                <?php 
                                    $addrType = 'billing';
                                    $addrNum = '2';
                                ?>
                                <?php $name = $addrType.'_street_'.$addrNum; $value=( isset($client) ? $client[$name] : ''); ?>
                                <?php echo render_textarea( $name, 'l_street',$value); ?>
                                <?php $name = $addrType.'_zipcode_'.$addrNum; $value=( isset($client) ? $client[$name] : ''); ?>
                                <?php echo render_input( $name, 'l_zip',$value); ?>
                                <?php 
                                $name = $addrType.'_country_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$countries,array( 'id',array( 'name')), 'l_country',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = $addrType.'_state_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$billing_states_2,array( 'id',array( 'name')), 'l_state',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = $addrType.'_city_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$billing_cities_2,array( 'id',array( 'name')), 'l_city',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>

                            </div>
                           <div class="col-md-6">
                                <h4 class="no-mtop">
                                   <!--<i class="fa fa-question-circle" data-toggle="tooltip" data-title="<?php echo trans('l_customer_shipping_address_notice'); ?>"></i>-->
                                   <?php echo trans('l_shipping_address_2'); ?> <a href="#" class="pull-right customer-copy-billing-address-2"><small class="font-medium-xs"><?php //echo trans('l_customer_billing_copy'); ?></small></a>
                                </h4>
                                <hr />
                                <?php 
                                    $addrType = 'shipping';
                                    $addrNum = '2';
                                ?>
                                <?php $name = $addrType.'_street_'.$addrNum; $value=( isset($client) ? $client[$name] : ''); ?>
                                <?php echo render_textarea( $name, 'l_street',$value); ?>
                                <?php $name = $addrType.'_zipcode_'.$addrNum; $value=( isset($client) ? $client[$name] : ''); ?>
                                <?php echo render_input( $name, 'l_zip',$value); ?>
                                <?php 
                                $name = $addrType.'_country_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$countries,array( 'id',array( 'name')), 'l_country',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = $addrType.'_state_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$shipping_states_2,array( 'id',array( 'name')), 'l_state',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                                <?php 
                                $name = $addrType.'_city_id_'.$addrNum; 
                                $selected =( isset($client) ? $client[$name] : 1);
                                echo render_select( $name,$shipping_cities_2,array( 'id',array( 'name')), 'l_city',$selected,array('data-none-selected-text'=>trans('l_dropdown_non_selected_tex')));
                                ?>
                           </div>
                        </div>
                    <!--</form>-->
                  </div>                  
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
                <div class="form-group">
                    <div class="col-md-12">
                        <input type="submit" name="submit" value="<?= trans('l_submit') ?>" class="btn btn-primary pull-right">
                    </div>
                </div>

              <?php echo form_close(); ?>
              </div>
            <!-- /.nav-tabs-custom -->
          </div>    
<script>
</script>
<script>
    $(function(){
        $('.billing-same-as-customer-1').on('click', function(e) {
        e.preventDefault();
        $('textarea[name="billing_street_1"]').val($('textarea[name="addr1"]').val());
        $('input[name="billing_city_id_1"]').val($('input[name="city_id"]').val());
        $('input[name="billing_state_id_1"]').val($('input[name="state_id"]').val());
        $('input[name="billing_zipcode_1"]').val($('input[name="zipcode"]').val());
        $('select[name="billing_country_id_1"]').selectpicker('val', $('select[name="country_id"]').selectpicker('val'));
    });
        $('.billing-same-as-customer-2').on('click', function(e) {
        e.preventDefault();
        $('textarea[name="billing_street_2"]').val($('textarea[name="addr1"]').val());
        $('input[name="billing_city_id_2"]').val($('input[name="city_id"]').val());
        $('input[name="billing_state_id_2"]').val($('input[name="state_id"]').val());
        $('input[name="billing_zipcode_2"]').val($('input[name="zipcode"]').val());
        $('select[name="billing_country_id_2"]').selectpicker('val', $('select[name="country_id"]').selectpicker('val'));
    });     
    $('.customer-copy-billing-address-1').on('click', function(e) {
        e.preventDefault();
        $('textarea[name="shipping_street_1"]').val($('textarea[name="billing_street_1"]').val());
        $('input[name="shipping_city_id_1"]').val($('input[name="billing_city_id_1"]').val());
        $('input[name="shipping_state_id_1"]').val($('input[name="billing_state_id_1"]').val());
        $('input[name="shipping_zipcode_1"]').val($('input[name="billing_zipcode_1"]').val());
        $('select[name="shipping_country_id_1"]').selectpicker('val', $('select[name="billing_country_id_1"]').selectpicker('val'));
    });
        $('.customer-copy-billing-address-2').on('click', function(e) {
        e.preventDefault();
        $('textarea[name="shipping_street_2"]').val($('textarea[name="billing_street_2"]').val());
        $('input[name="shipping_city_id_2"]').val($('input[name="billing_city_id_2"]').val());
        $('input[name="shipping_state_id_2"]').val($('input[name="billing_state_id_2"]').val());
        $('input[name="shipping_zipcode_2"]').val($('input[name="billing_zipcode_2"]').val());
        $('select[name="shipping_country_id_2"]').selectpicker('val', $('select[name="billing_country_id_2"]').selectpicker('val'));
    });    
        // event called when the country select is changed
        $("#country_id").change(function(){
            // get the currently selected country ID
            var countryId = $(this).val();

            $.ajax({
                url: "<?= base_url('admin/customer/get_country_states/') ?>" + countryId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#state_id").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#state_id").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });

        $("#state_id").change(function(){
            // get the currently selected country ID
            var stateId = $(this).val();

            $.ajax({
                // make the ajax call to our server and pass the country ID as a GET variable
                //url: "get_provinces.php?country_id=" + countryId,
                url: "<?= base_url('admin/customer/get_state_cities/') ?>" + stateId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#city_id").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#city_id").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });

        // event called when the country select is changed
        $("#billing_country_id_1").change(function(){
            // get the currently selected country ID
            var countryId = $(this).val();

            $.ajax({
                url: "<?= base_url('admin/customer/get_country_states/') ?>" + countryId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#billing_state_id_1").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#billing_state_id_1").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });

        $("#billing_state_id_1").change(function(){
            // get the currently selected country ID
            var stateId = $(this).val();

            $.ajax({
                // make the ajax call to our server and pass the country ID as a GET variable
                //url: "get_provinces.php?country_id=" + countryId,
                url: "<?= base_url('admin/customer/get_state_cities/') ?>" + stateId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#billing_city_id_1").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#billing_city_id_1").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });
        // event called when the country select is changed
        $("#shipping_country_id_1").change(function(){
            // get the currently selected country ID
            var countryId = $(this).val();

            $.ajax({
                url: "<?= base_url('admin/customer/get_country_states/') ?>" + countryId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#shipping_state_id_1").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#shipping_state_id_1").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });

        $("#shipping_state_id_1").change(function(){
            // get the currently selected country ID
            var stateId = $(this).val();

            $.ajax({
                // make the ajax call to our server and pass the country ID as a GET variable
                //url: "get_provinces.php?country_id=" + countryId,
                url: "<?= base_url('admin/customer/get_state_cities/') ?>" + stateId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#shipping_city_id_1").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#shipping_city_id_1").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });

        // event called when the country select is changed
        $("#billing_country_id_2").change(function(){
            // get the currently selected country ID
            var countryId = $(this).val();

            $.ajax({
                url: "<?= base_url('admin/customer/get_country_states/') ?>" + countryId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#billing_state_id_2").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#billing_state_id_2").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });

        $("#billing_state_id_2").change(function(){
            // get the currently selected country ID
            var stateId = $(this).val();

            $.ajax({
                // make the ajax call to our server and pass the country ID as a GET variable
                //url: "get_provinces.php?country_id=" + countryId,
                url: "<?= base_url('admin/customer/get_state_cities/') ?>" + stateId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#billing_city_id_2").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#billing_city_id_2").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });
        // event called when the country select is changed
        $("#shipping_country_id_2").change(function(){
            // get the currently selected country ID
            var countryId = $(this).val();

            $.ajax({
                url: "<?= base_url('admin/customer/get_country_states/') ?>" + countryId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#shipping_state_id_2").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#shipping_state_id_2").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });

        $("#shipping_state_id_2").change(function(){
            // get the currently selected country ID
            var stateId = $(this).val();

            $.ajax({
                // make the ajax call to our server and pass the country ID as a GET variable
                //url: "get_provinces.php?country_id=" + countryId,
                url: "<?= base_url('admin/customer/get_state_cities/') ?>" + stateId,
            }).done(function(data) {
                // our ajax call is finished, we have the data returned from the server in a var called data
                data = JSON.parse(data);

                var len = data.length;

                $("#shipping_city_id_2").empty();
                for( var i = 0; i<len; i++){
                    var id = data[i]['id'];
                    var name = data[i]['name'];
                    
                    $("#shipping_city_id_2").append("<option value='"+id+"'>"+name+"</option>");
                }
            });
        });
    });
</script>

