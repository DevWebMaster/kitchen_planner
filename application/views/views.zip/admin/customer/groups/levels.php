<!-- DataTables -->
<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/datatables/dataTables.bootstrap4.css"> 

<?php
        $this->load->helper('xcrud');
        $xcrud = xcrud_get_instance();
        $xcrud->table('gb_customer_level');
        $xcrud->columns('title, discount_rate');
        $xcrud->fields('title, discount_rate');
        $xcrud->label('title','Title');
        $xcrud->label('discount_rate','Discount Rate');

        $xcrud->unset_title();
        $xcrud->unset_remove(true);

        $xcrud->pass_var ('created_at', date('Y-m-d H:i:s'), 'create');
        $xcrud->pass_var ('created_by', $this->session->admin_id, 'create');
        $xcrud->pass_var ('updated_at', date('Y-m-d H:i:s'), 'edit');
        $xcrud->pass_var ('updated_by', $this->session->admin_id, 'edit');

        $content = $xcrud->render();
?>
<!-- Content Wrapper. Contains page content -->
<div class="col-md-9">
    <!-- For Messages -->
    <?php $this->load->view('admin/includes/_messages.php') ?>
    <div class="card">
      <div class="card-header">
        <div class="d-inline-block">
          <h3 class="card-title"><i class="fa fa-list"></i>&nbsp; <?= $tab['name'] ?></h3>
        </div>
        <div class="d-inline-block float-right">
       
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body table-responsive">
        <?php echo $content ?>
      </div>
    </div>
    </div>