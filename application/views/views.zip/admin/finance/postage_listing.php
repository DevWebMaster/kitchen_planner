
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <section class="content">
    <!-- For Messages -->
    <?php $this->load->view('admin/includes/_messages.php') ?>
    <div class="card">
      <div class="card-header">
        <div class="d-inline-block">
          <h3 class="card-title"><i class="fa fa-list"></i>&nbsp; <?= trans('l_postage_title') ?></h3>
        </div>
        <div class="d-inline-block float-right">
       
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="row m-1">
          <div class="col-2 pt-1"><?= trans('l_postage_effective_date');?>: </div> 
          <div class="col-10">
          <?php foreach($date_items as $date_item ) { ?>  

            <?php   if($date == trim($date_item['date'])) { ?>  
                <a class="btn btn-info btn-sm" href="<?= base_url('admin/finance/postage_fee/'.$date_item['date']) ?>"><?= $date_item['year'].'-'.$date_item['month'].'-'.$date_item['day'] ;  ?></a>    
            <?php } else  { ?>  
                <a class="btn btn-dark btn-sm" href="<?= base_url('admin/finance/postage_fee/'.$date_item['date']) ?>"><?= $date_item['year'].'-'.$date_item['month'].'-'.$date_item['day'] ;  ?></a>    
            <?php }  ?>  
          <?php } ?>
          </div><!-- /div-10  -->
        </div><!-- /row  -->
        <div class="row m-1">
          <div class="col-2 pt-1"><?= trans('l_postage_rate_type');?>: </div> 
          <div class="col-10">
            <?php foreach($rate_type_list as $rate_type_item ) { ?>  
              <?php if($rate_type == $rate_type_item['rate_type_id']) { ?>  
                <a class="btn btn-info btn-sm" href="<?= base_url('admin/finance/postage_fee/'.$date.'/'.$rate_type_item['rate_type_id']) ?>"><?= $rate_type_item['title'] ;  ?></a>    
              <?php } else { ?>            
                <a class="btn btn-dark btn-info btn-sm" href="<?= base_url('admin/finance/postage_fee/'.$date.'/'.$rate_type_item['rate_type_id']) ?>"><?= $rate_type_item['title'] ;  ?></a>    
              <?php }  ?>            
            <?php }  ?>
          </div><!-- /div-10  -->
        </div><!-- /row  -->
        <?php if ($rate_type==3) { ?>
        <div class="row m-1">
          <div class="col-2 pt-1"><?= trans('l_postage_customer_level');?>: </div> 
          <div class="col-10">
                <?php foreach($customer_level_list as $customer_level_item ) { ?>  
                  <?php if($customer_level_id == $customer_level_item['id'] || $customer_level_id==0) { ?>  
                    <a class="btn btn-info btn-sm" href="<?= base_url('admin/finance/postage_fee/'.$date.'/'.$rate_type.'/'.$customer_level_item['id'] ); ?>"><?= $customer_level_item['title'] ;  ?></a>    
                  <?php } else {  ?>
                    <a class="btn btn-dark btn-info btn-sm" href="<?= base_url('admin/finance/postage_fee/'.$date.'/'.$rate_type.'/'.$customer_level_item['id'] ); ?>"><?= $customer_level_item['title'] ;  ?></a>   
                  <?php  } ?>
                <?php  } ?>
          </div><!-- /div-10  -->
        </div><!-- /row  -->
        <?php  } ?><!-- end if rate type 3  -->

      </div>
    </div>
    <div class="card">
      <div class="card-body table-responsive">
        <?php echo $content ?>
          
      </div>
    </div>
  </section>  
</div>
