  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <div class="card card-default">
        <div class="card-header">
          <div class="d-inline-block">
              <h3 class="card-title"> <i class="fa fa-plus"></i>
             <?= trans('l_role_permission_menu') ?> </h3>
          </div>
        </div>
        <div class="card-body">
            <?php $this->load->view('admin/includes/_messages.php') ?>
            <?php echo form_open(base_url('admin/Role_Rel_Permission/update_role_permission'), 'class="form-horizontal"');  ?> 

            <div class="accordion" id="accordionRoleRelPermission">
                <?php foreach ($roles as $role) {
                    $collapseName = "collapse".$role['id'];
                ?>
                <div class="card">
                    <div class="card-header" id="headingOne">
                        <h2 class="mb-0">
                            <button type="button" class="btn btn-link" data-toggle="collapse" data-target="#<?php echo $collapseName?>"><?php echo $role['title'] ?></button>									
                        </h2>
                    </div>
                    <div id="<?php echo $collapseName?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionRoleRelPermission">
                        <div class="card-body">
                            <?php foreach ($permissions as $permission) {
                                $chkboxId = $role['id']."_".$permission['id'];
                            ?>
                            <div class="form-check">
                                
                                <?php 
                                    if($chkbox[$chkboxId] == 1){ 
                                        echo '<input name="'.$chkboxId.'" type="checkbox" class="form-check-input" id="'.$chkboxId.'" checked>';
                                    }
                                    else{
                                        echo '<input name="'.$chkboxId.'" type="checkbox" class="form-check-input" id="exampleCheck1">';
                                    }
                                ?>
                                <label class="form-check-label" for="<?php echo $chkboxId ?>"><?php echo $permission['title']?></label>
                            </div>                            
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            <div class="form-group">
                <div class="col-md-12">
                    <input type="submit" name="submit" value="<?= trans('l_update') ?>" class="btn btn-primary pull-right">
                </div>
            </div>
            <?php echo form_close( ); ?>
        </div>          
          <!-- /.box-body -->
      </div>
    </section> 
  </div>