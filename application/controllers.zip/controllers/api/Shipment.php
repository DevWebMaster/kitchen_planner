<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class Shipment extends RestController {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->database('default');
        $this->lang->load(array('api/api.php','api/shipment.php'));
        $this->load->model('api/parcel_model','parcel_model');
        $this->load->model('api/shipment_model','shipment_model');
    }



public function remove_post()
 {

    $header = getallheaders();

    $p_code = ( !empty($header['p_code']) ) ? $header['p_code'] : ''; 
    $api_key = ( !empty( $header['api_key'] ) ) ? $header['api_key'] : ''; 
    $branch = ( !empty( $header['branch'] ) ) ? $header['branch'] : ''; 
    $lang = ( !empty( $header['lang'] ) ) ? trim($header['lang']) : 'en'; 
    $isError = FALSE;
    if($lang=='cn')
        $this->lang->load(array('api/api.php','api/shipment.php'),'chinese');
    //$this->lang->load(array('api/parcel.php'),'chinese');

    $rtnarr = array();
    $data = json_decode(file_get_contents('php://input'), true);

    if( empty($p_code) || empty($branch) || empty($api_key) )
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key_require');
      }


    $customer_info = $this->parcel_model->checkHash($p_code,$branch, $api_key);
    if($customer_info===FALSE)
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key');
      }        
    else 
      {   $customer_id = $customer_info['customer_id'];
          $branch = $branch;

          $ship_no = ( !empty($data['ship_no']) && trim($data['ship_no'])!="" ) ? trim($data['ship_no']) : '';
          if($ship_no=="")  {  
              $isError = TRUE;     
              $message[] = trans('l_e_shipno');  
            }

          $ship_name = ( !empty($data['ship_name']) && trim($data['ship_name'])!="" ) ? trim($data['ship_name']) : '';
          if($ship_name=="")  {  
              $isError = TRUE;     
              $message[] = trans('l_e_shipname');  
            }
          
          $tracking_no =  ( !empty($data['tracking_no'])) ? $data['tracking_no'] : '';
          if(count($tracking_no)==0)  {  
              $isError = TRUE;     
              $message[] = trans('l_e_tacking_no');  
            }
          
          $hash = ( !empty($data['hash']) && trim($data['hash'])!="" ) ? trim($data['hash']) : '';
          if($hash=="")  {  
              $isError = TRUE;     
              $message[] = trans('l_e_hash_key');  
            }


          // check hash key   
          if(!$isError)
            {  
              $check_hash = md5($customer_info['secret_key'].$ship_no.$ship_name);
              if($hash!==$check_hash)
                {
                  $isError = TRUE;     
                  $message[] = trans('l_e_hash_check'); 
                }
            }

               

          if(!$isError)
            { 
              // create shipment master 
              $this->db->trans_start();
              
              // check if the shiment no already exist    
              $shipment_arr = $this->shipment_model->check_shipno($ship_no,$customer_info); 

              if($shipment_arr===FALSE)
              {
                  $isError = TRUE;     
                  $message[] = trans('l_e_shipment_not_exist'); 
              }
              else 
                $shipment_id = $shipment_arr['shipment_id'];

              if($shipment_id!==FALSE)
                { 
                  $cnt=0;  
                  foreach($tracking_no as $track)
                    {      
                        $parcel_info= $this->parcel_model->get_parcel_from_tracking($track,$customer_info);
                        
                        $parcel_id = $parcel_info[0]['parcel_id'];
                        $data_track = array(
                            'shipment_detail_id'=>0,    'shipment_id'=>$shipment_id,
                            'parcel_id'=>$parcel_id,    'manisfest_status'=>0,
                            'rec_status'=>1  
                          );                        

                        // check if parcel already in the shipment details
                        if( $this->shipment_model->remove_parcel_from_shipment($shipment_id,$parcel_id) ===FALSE )
                          {
                              $rtn_arr[] = array(  'status'=>'E',   'tracking_no'=>$track, 
                                                 'remark'=>trans('l_e_tracking_remove_fails')   ); 
                          }
                        else 
                          {   $rtn_arr[] = array( 'status'=>'S',    'tracking_no'=>$track, 
                                                  'remark'=>trans('l_e_tracking_remove_success') );
                          }  
                    }
                } 
              else 
                {
                    $isError = TRUE;     
                    $message[] = trans('l_e_shipment_not_exist'); 
                }     
            }

          if($isError)
            {   
                $rtn = array('status'=>'E', 'message'=>$message); 
                $this->db->trans_rollback();
                $this->response( $rtn, 500 );
            }
          else  
            {   
                $rtn = $rtn_arr; 
                $this->db->trans_complete();
                $this->response( $rtn, 200 );
            }  
      } 

 }

public function getlist_post()
 {
    $header = getallheaders();

    $p_code = ( !empty($header['p_code']) ) ? $header['p_code'] : ''; 
    $api_key = ( !empty( $header['api_key'] ) ) ? $header['api_key'] : ''; 
    $branch = ( !empty( $header['branch'] ) ) ? $header['branch'] : ''; 
    $lang = ( !empty( $header['lang'] ) ) ? trim($header['lang']) : 'en'; 
    $isError = FALSE;
    if($lang=='cn')
        $this->lang->load(array('api/api.php','api/shipment.php'),'chinese');
    //$this->lang->load(array('api/parcel.php'),'chinese');

    $rtnarr = array();
    $data = json_decode(file_get_contents('php://input'), true);

    if( empty($p_code) || empty($branch) || empty($api_key) )
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key_require');
      }


    $customer_info = $this->parcel_model->checkHash($p_code,$branch, $api_key);
    if($customer_info===FALSE)
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key');
      }  
    else 
      {
          $start =  ( !empty($data['rec_no'])) ? $data['rec_no'] : 0;
          if($start>0)    $limit1 = $start-1;   
          else            $limit1=0;          

          $limit2 = 5000;

          $ship_no = ( !empty($data['ship_no']) && trim($data['ship_no'])!="" ) ? trim($data['ship_no']) : '';
          if($ship_no=="")  {  
              $isError = TRUE;     
              $message[] = trans('l_e_shipno');  
            }
            
          if(!$isError)
            {  
                $rtnarr = $this->shipment_model->get_parcel_by_shipment($ship_no,$customer_info['customer_id'],$limit1,$limit2);
                if($isError)
                  {   
                    $rtn = array('status'=>'E', 'message'=>$message); 
                    $this->response( $rtn, 500 );
                  }
                else  
                  {   
                    $rtn = $rtnarr; 
                    $this->response( $rtn, 200 );
                  }  
            }      
      }
 }

public function create_post()
 {

 	  $header = getallheaders();

    $p_code = ( !empty($header['p_code']) ) ? $header['p_code'] : ''; 
    $api_key = ( !empty( $header['api_key'] ) ) ? $header['api_key'] : ''; 
    $branch = ( !empty( $header['branch'] ) ) ? $header['branch'] : ''; 
    $lang = ( !empty( $header['lang'] ) ) ? trim($header['lang']) : 'en'; 
    $isError = FALSE;
    if($lang=='cn')
        $this->lang->load(array('api/api.php','api/shipment.php'),'chinese');
    //$this->lang->load(array('api/parcel.php'),'chinese');

    $rtnarr = array();
    $data = json_decode(file_get_contents('php://input'), true);

    if( empty($p_code) || empty($branch) || empty($api_key) )
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key_require');
      }


    $customer_info = $this->parcel_model->checkHash($p_code,$branch, $api_key);
    if($customer_info===FALSE)
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key');
      }        
    else 
      {   $customer_id = $customer_info['customer_id'];
          $branch = $branch;

          $ship_no = ( !empty($data['ship_no']) && trim($data['ship_no'])!="" ) ? trim($data['ship_no']) : '';
          if($ship_no=="")  {  
              $isError = TRUE;     
              $message[] = trans('l_e_shipno');  
            }

          $ship_name = ( !empty($data['ship_name']) && trim($data['ship_name'])!="" ) ? trim($data['ship_name']) : '';
          /*if($ship_name=="")  {  
              $isError = TRUE;     
              $message[] = trans('l_e_shipname');  
            }*/
          
          $tracking_no =  ( !empty($data['tracking_no'])) ? $data['tracking_no'] : '';
          if(count($tracking_no)==0)  {  
              $isError = TRUE;     
              $message[] = trans('l_e_tacking_no');  
            }
          
          $hash = ( !empty($data['hash']) && trim($data['hash'])!="" ) ? trim($data['hash']) : '';
          if($hash=="")  {  
              $isError = TRUE;     
              $message[] = trans('l_e_hash_key');  
            }


          // check hash key   
          if(!$isError)
            {  
              $check_hash = md5($customer_info['secret_key'].$ship_no.$ship_name);
              if($hash!==$check_hash)
                {
                  $isError = TRUE;     
                  $message[] = trans('l_e_hash_check'); 
                }
            }

               

          if(!$isError)
            { 
              // create shipment master 
              $this->db->trans_start();
              
              // check if the shiment no already exist    
              $shipment_arr = $this->shipment_model->check_shipno($ship_no,$customer_info); 

              if($shipment_arr===FALSE)
              {
                $datax = array(
                    'shipment_id'=>0,           'code'=>$ship_no,       'name_en'=>$ship_name,    
                    'name_cn'=>$ship_name,      'customer_id'=>$customer_info['customer_id'],
                    'branch_code'=>$branch,     'is_internal'=>0,
                    'customer_created_at'=>date("Y-m-d h:i:s"), 
                    'customer_created_by'=>$customer_info['customer_id'],
                    'shipment_status_id'=>1,    'rec_status'=>1  
                    );

                $shipment_id = $this->shipment_model->create_shipment($datax);
              }
              else 
                $shipment_id = $shipment_arr['shipment_id'];

              if($shipment_id!==FALSE)
                { 
                  $cnt=0;  
                  foreach($tracking_no as $track)
                    {      
                        $parcel_info= $this->parcel_model->get_parcel_from_tracking($track,$customer_info);
                        
                        $parcel_id = $parcel_info[0]['parcel_id'];
                        $data_track = array(
                            'shipment_detail_id'=>0,    'shipment_id'=>$shipment_id,
                            'parcel_id'=>$parcel_id,    'manisfest_status'=>0,
                            'rec_status'=>1  
                          );                        

                        // check if parcel already in the shipment details
                        if( $this->shipment_model->check_shipment_duplicate($parcel_id) ===FALSE )
                          {
                              $shipment_detail_id = $this->shipment_model->add_parcel_to_shipment($data_track);
                              if($shipment_detail_id)
                                {
                                   $rtn_arr[] = array( 'status'=>'S', 'tracking_no'=>$track, 'remark'=>trans('l_e_tracking_add_success') );
                                }
                              else 
                                  $rtn_arr[] = array(  'status'=>'F', 'tracking_no'=>$track, 'remark'=>trans('l_e_tracking_add_fail') ); 
                              $cnt++;
                          }
                        else 
                         {
                            $rtn_arr[] = array(  'status'=>'E', 'tracking_no'=>$track, 
                                                 'remark'=>trans('l_e_tracking_already_exist')   ); 
                         }  
                    }
                } 
              else 
                {
                    $isError = TRUE;     
                    $message[] = trans('l_e_shipment_created'); 
                }     
            }

          if($isError)
            {   
                $rtn = array('status'=>'E', 'message'=>$message); 
                $this->db->trans_rollback();
                $this->response( $rtn, 500 );
            }
          else  
            {   
                $rtn = $rtn_arr; 
                $this->db->trans_complete();
                $this->response( $rtn, 200 );
            }  
      }	

 }


public function create_get()
 {
 	echo 'testing ';
 }

} 
?>