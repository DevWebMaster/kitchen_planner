<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;


class Parcel extends RestController {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->database('default');
        $this->lang->load(array('api/api.php','api/parcel.php'));
        $this->load->model('api/parcel_model','parcel_model');
        $this->load->library('api');
    }


public function create_post()
 {
    // check header info
    $header_info = $this->api->check_header();
    
    // load language file 
    if($header_info['data']['lang']=='cn') 
       $this->lang->load(array('api/api.php','api/parcel.php'),'chinese');

    $isError=FALSE;

    if($header_info['status']==false)
     {
        $isError=TRUE;     
        $message[] = $header_info['message'][0];
     }
    
   // validate customer 
    $customer_info = $this->parcel_model->checkHash($header_info['data']['p_code'],$header_info['data']['branch'],$header_info['data']['api_key'] ); 

    if($customer_info===FALSE)
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key');
      }        
    else 
      { 
        // initialise variable 
        $customer_id = $customer_info['customer_id']; 
        $secret_key = $customer_info['secret_key'];
        $customer_level_id = $customer_info['customer_level_id'];
        $branch = $header_info['data']['branch'];
        $customer_name  = 'dummy';               $customer_email  = 'dummy';
        $customer_contact = ' ';
        $payment_company= ' ';         $payment_firstname= 'fname';         $payment_lastname = ' ';        
        $payment_addr1 = ' ';         $payment_addr2   = ' ';
        $payment_city= ' ';         $payment_city_id= ' ';         $payment_postcode= ' ';         
        $payment_state= ' ';
        $payment_state_id= ' ';         $payment_country= ' ';         $comment= ' ';         $total= 0;
        $order_status_id=0;    
      }  

    // get json data 
    $data = json_decode(file_get_contents('php://input'), true); 

    // create order and load txcd 
    if( !$isError)
      {  
      
        // create order record 
        $this->db->trans_start();
        // write to oder records 
        $total = '';

        $data_order=array('order_id'=>0,             'invoice_prefix'=>C_INVOICE_PRE,
            'customer_id'=>$customer_id,            'customer_branch_code'=>$branch,          'customer_level_id'=>$customer_level_id,
            'customer_name'=>$customer_name,        'customer_email'=>$customer_email,        'customer_contact'=>$customer_contact,  
            'payment_company'=>$payment_company,    'payment_firstname'=>$payment_firstname,  'payment_lastname'=>$payment_lastname,
            'payment_addr1'=>$payment_addr1,        'payment_addr2'=>$payment_addr2,          'payment_city'=>$payment_city,
            'payment_city_id'=>$payment_city_id,    'payment_postcode'=>$payment_postcode,    'payment_state'=>$payment_state,
            'payment_state_id'=>$payment_state_id,  'payment_country'=>$payment_country,      'comment'=>$comment,
            'total'=>$total,                        'order_status_id'=>$order_status_id       

           
          );
        $order_id = $this->parcel_model->create_order($data_order);
        
        if($order_id===FALSE)
         {  $isError=TRUE;     
            $message[] = trans('l_e_order_error');
         }
       
        // load transaction code
        $txcd_info = $this->parcel_model->get_service_txcd(); 
        foreach($txcd_info as $fmtarr)
        {
            $txcd_item[$fmtarr['service_code']] = array('txcd'=>$fmtarr['txcd'],  
                    'title_en'=>$fmtarr['title_en'],    'title_cn'=>$fmtarr['title_cn'] 
                     );
        } 


      }    
    // check input json identifier   
    if(!isset($data['packages']))
      {
            $isError=TRUE;     
            $message[] = trans('l_e_invalid_resquest');
      }  
    
    // read each json record
    if( !$isError)
      {  
         $total = 0; 

         foreach ($data['packages'] as $key=>$item)
            { 

              

            //tabulate input data and validate data 
                $status = true;
                $rec_no = $key;
                $message= array();

                $weight = $item['package_total_gross_weight']['value'];
                $weight_unit = $item['package_total_gross_weight']['unit'];

                $dimension_unit = ( !empty($item['package_dimensions']['unit']) ) ? trim($item['package_dimensions']['unit']) : '';
                
                if ( $dimension_unit!="" && !$this->chk_field_table('gb_parm_dimension_unit','code',$dimension_unit,'rec_status=1') )
                    {   $status = false;   $message[] = trans('l_e_dimension_unit');       } 
                $length = (!empty($item['package_dimensions']['length']) && is_numeric($item['package_dimensions']['length']) ) ? $item['package_dimensions']['length']  : 0;
                $width = (!empty($item['package_dimensions']['width']) && is_numeric($item['package_dimensions']['width']) ) ? $item['package_dimensions']['width']  : 0; 
                $height = (!empty($item['package_dimensions']['height']) && is_numeric($item['package_dimensions']['height']) ) ? $item['package_dimensions']['height']  : 0; 

                $insurance_info = $item['insurance_value'];

                $has_dangerous_goods = (!empty($item['has_dangerous_goods']) && is_numeric($item['has_dangerous_goods']) ) ? $item['has_dangerous_goods']  : 0; 
                
                $has_hazardous_material = (!empty($item['has_hazardous_material']) && is_numeric($item['has_hazardous_material']) ) ? $item['has_hazardous_material']  : 0; 
 
 
                $send_firm = (!empty($item['ship_from']['send_firm'])) ? trim($item['ship_from']['send_firm']):'';
                
                // send name
                $send_name = (!empty($item['ship_from']['send_name'])) ? trim($item['ship_from']['send_name']):'';
                if($send_name == "")  
                 {  
                    $status = false;     
                    $message[] = trans('l_e_send_name');  
                 }  

                // address
                $send_addr1 = (!empty($item['ship_from']['send_addr1'])) ? trim($item['ship_from']['send_addr1']) : '';
                if($send_addr1 == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_addr1');  }  

                $send_addr2 = (!empty($item['ship_from']['send_addr2'])) ? trim($item['ship_from']['send_addr2']) : '';
                
                // city
                $send_city = (!empty($item['ship_from']['send_city_locality'])) ? trim($item['ship_from']['send_city_locality']) : '';
                if($send_city == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_city');  }         

                // state    
                $send_state = (!empty($item['ship_from']['send_state_province'])) ? trim($item['ship_from']['send_state_province']) : '';
                if($send_state == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_state');  }         

                // zip code    
                $send_zip_code = (!empty($item['ship_from']['send_zip_postal_code'])) ? trim($item['ship_from']['send_zip_postal_code']) : '';   
                if($send_zip_code == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_zip_code');  }         
                
                $send_zip4_code = (!empty($item['ship_from']['send_zip4_code'])) ? trim($item['ship_from']['send_zip4_code']) : '';
                
                $send_country = (!empty($item['ship_from']['send_country_code'])  ) ? trim($item['ship_from']['send_country_code']) : '';
                if($send_country == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_country');  }        

                $send_email = ( !empty($item['ship_from']['send_email'])  ) ? trim($item['ship_from']['send_email']) : '';   
                $send_sms = ( !empty($item['ship_from']['send_sms'])  ) ? trim($item['ship_from']['send_sms']) : '';

                $send_address_residential_indicator = ( !empty($item['ship_from']['send_address_residential_indicator']) && is_numeric($item['ship_from']['send_address_residential_indicator'])  ) ? trim($item['ship_from']['send_address_residential_indicator']) : '0';   
                         
                // receive
                $recv_firm = ( !empty($item['ship_to']['recv_firm'])  ) ? trim($item['ship_to']['recv_firm']) : '';
                $recv_name = ( !empty($item['ship_to']['recv_name'])  ) ? trim($item['ship_to']['recv_name']) : '';
                if($recv_name == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_name');  }  

                $recv_addr1 = ( !empty($item['ship_to']['recv_addr1'])  ) ? trim($item['ship_to']['recv_addr1']) : '';
                if($recv_addr1 == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_addr1');  }         

                $recv_addr2 = ( !empty($item['ship_to']['recv_addr2'])  ) ? trim($item['ship_to']['recv_addr2']) : '';
                $recv_city = ( !empty($item['ship_to']['recv_city_locality'])  ) ? trim($item['ship_to']['recv_city_locality']) : '';
                if($recv_city == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_city');  }

                $recv_state = ( !empty($item['ship_to']['recv_state_provice'])  ) ? trim($item['ship_to']['recv_state_provice']) : '';
                if($recv_state == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_state');  }                

                $recv_zip_code = ( !empty($item['ship_to']['recv_zip_postal_code'])  ) ? trim($item['ship_to']['recv_zip_postal_code']) : '';   
                if($recv_zip_code == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_zip_code');  }    

               /* $recv_zip4_code = ( !empty($item['ship_to']['recv_zip4_code'])  ) ? trim($item['ship_to']['recv_zip4_code']) : '';  */
                $recv_zip4_code = '';
                $recv_country = ( !empty($item['ship_to']['recv_country_code'])  ) ? trim($item['ship_to']['recv_country_code']) : '';   
                if($recv_country == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_country');  }  
                
                $recv_email = ( !empty($item['ship_to']['recv_email'])  ) ? trim($item['ship_to']['recv_email']) : '';
                $recv_sms = ( !empty($item['ship_to']['recv_sms'])  ) ? trim($item['ship_to']['recv_sms']) : '';   

                $recv_address_residential_indicator = ( !empty($item['ship_to']['recv_address_residential_indicator']) && is_numeric($item['ship_to']['recv_address_residential_indicator'])  ) ? trim($item['ship_to']['recv_address_residential_indicator']) : '0';   

                $recv_original = $item['ship_to'];   

/***********************************************************************************/
/*  Address validation - link to USPS API - start */
/***********************************************************************************/
    $request_doc_template = <<<EOT
    <?xml version="1.0"?>
    <AddressValidateRequest USERID="101INFIN5857"><Revision>1</Revision>
    <Address ID="0"><Address1>$recv_addr1</Address1><Address2>$recv_addr2</Address2>
    <City>$recv_city</City><State>$recv_state</State><Zip5>$recv_zip_code</Zip5><Zip4/></Address>
    </AddressValidateRequest>
    EOT;

    // prepare xml doc for query string
    $doc_string = preg_replace('/[\t\n]/', '', $request_doc_template);
    $doc_string = urlencode($doc_string);
    $ext_api_url = "http://production.shippingapis.com/ShippingAPI.dll?API=Verify&XML=" . $doc_string;
    // perform the get
    $response = file_get_contents($ext_api_url);
    
    $xml=simplexml_load_string($response) or die("Error: Cannot create object");
    // print_r($xml);
    
    if($xml->Address->Error)
     {
        $status = false;     
        $message[] = trans('l_e_recv_invalid');
     }
    else 
     {    
        $recv_addr1 = (string)$xml->Address->Address1;
        $recv_addr2 = (string)$xml->Address->Address2;
        $recv_city = (string)$xml->Address->City;
        $recv_state = (string)$xml->Address->State;
        $recv_zip_code = (string)$xml->Address->Zip5;
        $recv_zip4_code = (string)$xml->Address->Zip4;
     }
    

/***********************************************************************************/
/*  Address validation - end  */
/***********************************************************************************/

                $hash_key = ( !empty($item['hash_key'])  ) ? trim($item['hash_key']) : '';   
                if($hash_key == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_hash_key');  }    
                                    
                $hash = md5($secret_key.$weight.$weight_unit.$length.$width.$height.$dimension_unit.$recv_addr1.$recv_addr2.$recv_city.$recv_state.$recv_zip_code.$recv_country);
                //echo $hash;
/* -------------------------------------------------------------------------------- */               
/***********************************************************************************/
/*  Skip hash check  */
/* -------------------------------------------------------------------------------- */               
/*
                if( $hash !== $hash_key )
                {
                    $status = false;     
                    $message[] = trans('l_e_hash_check');
                }
*/

                $customer_ref_info = $item['customer_reference'];
                $service_info = $item['service_request'];
                $package_content = $item['package_content'];

            // format data weigth and mass 
                $dim = array($length, $width, $height);    
                rsort($dim,1);
                $dimension = get_dimension_info($dim,$dimension_unit);
                $mass = get_mass_info($weight,$weight_unit); 
                   
                //Girth (G) = ( 2 x Height) + (2 x Width)
                $girth = ( 2*$dimension['height']['in'] ) + ( 2*$dimension['width']['in'] );
                $cubic_ft = $dimension['length']['ft']*$dimension['width']['ft']*$dimension['height']['ft'];
                $dimension_weight = ($dimension['length']['in']*$dimension['height']['in']*$dimension['width']['in'])/166;
            
            // get zone info and format facility info
                $zone_info = $this->parcel_model->get_zone($recv_zip_code); 
                $facility_id = $zone_info[0]['facility_id'];
                $zone_code = $zone_info[0]['zone_code'];

                $facility_info= array(
                 'facility_name'=>$zone_info[0]['facility_name'],  'entry_type'=>$zone_info[0]['entry_type'],
                 'entry_zipcode'=>$zone_info[0]['entry_zipcode'],  'entry_zipcode4'=>$zone_info[0]['entry_zipcode4'], 
                 'rtn_addr1'=>$zone_info[0]['rtn_addr1'],          'rtn_addr_city'=>$zone_info[0]['rtn_addr_city'],
                 'rtn_addr_state'=>$zone_info[0]['rtn_addr_state'],'rtn_addr_zip'=>$zone_info[0]['rtn_addr_zip'], 
                 'sender_name'=>$zone_info[0]['sender_name'],      'sender_email'=>$zone_info[0]['sender_email'], 
                 'sender_sms'=>$zone_info[0]['sender_sms'],        'additional_info'=>$zone_info[0]['additional_info']
                );     

    /****************************************************************************************************/
    /* check service info  -  if service info empty or don't have last mile service quote, then reject  */
    /***************************************************************************************************/            
            
            if( count($service_info)==0 || in_array('01000', $service_info)==false )
              {
                    $status = false;     
                    $message[] = trans('l_e_service_code_invalid');
                    // format the return message before skip to next iteration
                    $rtnarr[$rec_no]=array( 'record_no'=>$record_no,     'status'=>'E',      'message'=>$message,
                            'customer_reference'=>$customer_ref_info );

                    continue;

              }



    /************************************************************************************************************/
    /*  Loop Service - start              */        
    /************************************************************************************************************/
            
            
            $subtotal = 0; 
            $rtn_service = array();
            $response = array();
            $chargeable_weight= $mass['lbs'];
            
            foreach ($service_info as $service_code)
              {    

                
    /************************************************************************************************************/
    /*  Last mile serive 01000 - start            */        
    /************************************************************************************************************/

                //  get price   if service code is 01000
                if( $status==true && $service_code =="01000" )
                  {  
                    $final_rate = array();  // final rate for customer rate 
                    $providerinfo = array(); // provider infor based on customer rate 
                    
                    $final_cost_arr = array(); // final rate for cost rate 
                    $providerinfo_cost = array(); // provider infor based on cost rate
                            
                    $rate_arr = array(); // temp place holder for final rate
                    $cost_arr = array(); // temp place holder for cost arr   
        
        // check first class ************************************************************************************ 
        
                    if( $dimension['length']['in'] <=22 && $dimension['width']['in'] <=18 && $dimension['height']['in'] <=15 && $mass['lbs']< 1 )
                        {      
                            $rate_arr = $this->parcel_model->get_firstclass_rate($mass['oz'],$zone_code);
                            $rate_arr = get_price_rate($rate_arr);
                            
                            if( count($final_rate)==0 || ( count($rate_arr)>0 && $rate_arr[$customer_level_id] < $final_rate[$customer_level_id] ) )
                             {
                                $final_rate = $rate_arr;
                                $providerinfo = $this->parcel_model->get_carrier_service_type(1);
                             }     
                            // cost    
                            if( count($final_cost_arr)==0 || ( count($rate_arr)>0 && $rate_arr['cost'] < $final_cost_arr['cost'] ) )
                             {
                                $final_cost_arr =  $rate_arr;
                                $providerinfo_cost = $this->parcel_model->get_carrier_service_type(1);
                             }      
                        }   

        // check commercial cubic ********************************************************************************** 
                             
                    if( ($dimension['length']['in']+$girth)<=108 && $cubic_ft <= 0.5 && $mass['lbs'] <= 20 )
                        { 
                            $rate_arr = $this->parcel_model->get_comm_cubic_rate($cubic_ft,$zone_code);
                            $rate_arr = get_price_rate($rate_arr);
                            
                            if( count($final_rate)==0 || ( count($rate_arr)>0 && $rate_arr[$customer_level_id]<$final_rate[$customer_level_id] ) )
                             {
                                $final_rate = $rate_arr;
                                $providerinfo = $this->parcel_model->get_carrier_service_type(3);

                                //$providerinfo = array( 'type'=>"C", 'rate_ind'=>'CP', 'mailclass' =>'PM'  );      
                             }    
                            // cost    
                            if( count($final_cost_arr)==0 || ( count($rate_arr)>0 && $rate_arr['cost'] < $final_cost_arr['cost'] ) )
                             {
                                $final_cost_arr =  $rate_arr;
                                $providerinfo_cost = $this->parcel_model->get_carrier_service_type(1);
                             }                
                        }   
                    
        // check priority mail commercial plus  ***************************************************************** 
                              
                    if( ($dimension['length']['in']+$girth)<=108  && $mass['lbs'] <= 70 )
                        {   
                            if( $cubic_ft <= 1)
                            {   $rate_arr = $this->parcel_model->get_comm_plus_rate($mass['lbs'],$zone_code);
                                //echo $this->db->last_query();
                            }
                            else
                            {   
                                if($dimension_weight > $mass['lbs']) 
                                    $chargeable_weight=$dimension_weight;
                                
                                $rate_arr = $this->parcel_model->get_comm_plus_rate( max($dimension_weight,$mass['lbs'] ),$zone_code);   
                            } 
                            
                            $rate_arr = get_price_rate($rate_arr);

                            if( count($final_rate)==0 || ( count($rate_arr)>0 && $rate_arr[$customer_level_id]<$final_rate[$customer_level_id] ) )
                             {
                                $final_rate = $rate_arr;
                                $providerinfo = $this->parcel_model->get_carrier_service_type(2);
                                //$providerinfo = array( 'type'=>"C", 'rate_ind'=>'SP', 'mailclass' => 'PM'  );      
                             }                         
                        
                            // cost    
                            if( count($final_cost_arr)==0 || ( count($rate_arr)>0 && $rate_arr['cost'] < $final_cost_arr['cost'] ) )
                             {
                                $final_cost_arr =  $rate_arr;
                                $providerinfo_cost = $this->parcel_model->get_carrier_service_type(1);
                             } 

                        }   

                    $providerinfo = $providerinfo[0];   
                    $providerinfo_cost = $providerinfo_cost[0];

                    if( count($final_rate)==0 )
                        {
                            $status = false;     
                            $message[] = trans('l_e_rate_emtpy');
                        }    
                     

        /************************************************************************************************************/
        /*  Create Parcel - start            */        
        /************************************************************************************************************/
                if( $status == true )
                  {     
                        $sender_arr = array(
                            'send_firm'=>$send_firm,            'send_name'=>$send_name,            
                            'send_addr1'=>$send_addr1,          'send_addr2'=>$send_addr2,          
                            'send_city'=>$send_city,            'send_state'=>$send_state,
                            'send_zip_code'=>$send_zip_code,    'send_zip4_code'=>$send_zip4_code,  
                            'send_country'=>$send_country,      'send_email'=>$send_email,          
                            'send_sms'=>$send_sms,              
                            'send_address_residential_indicator'=>$send_address_residential_indicator  
                          );
                                
                        $recv_arr = array(
                            'recv_firm'=>$recv_firm,            'recv_name'=>$recv_name,            
                            'recv_addr1'=>$recv_addr1,          'recv_addr2'=>$recv_addr2,          
                            'recv_city'=>$recv_city,            'recv_state'=>$recv_state,
                            'recv_zip_code'=>$recv_zip_code,    'recv_zip4_code'=>$recv_zip4_code,  
                            'recv_country'=>$recv_country,      'recv_email'=>$recv_email,          
                            'recv_sms'=>$recv_sms, 
                            'recv_address_residential_indicator'=>$recv_address_residential_indicator 
                          );           
                       
                        // create parcel 
                        $data = array(  'parcel_id'=>0,     'customer_id'=>$customer_id,    
                            'customer_level_id'=>$customer_level_id,
                            'branch'=>$branch,
                            'bag_id'=> '',      'carton_id'=> '' ,      'box_id'=> '' ,
                            'container_id'=> '' ,   'mawb'=> '' ,       'hawb'=> '' ,
                            'weight_lbs'=>$mass['lbs'],         'weight_json'=>json_encode($mass),  
                            'length_in'=>$dimension['length']['in'],
                            'length_json' =>json_encode($dimension['length']),              
                            'width_in'=>$dimension['width']['in'] ,
                            'width_json'=>json_encode($dimension['width']),                 
                            'height_in'=>$dimension['height']['in'] ,
                            'height_json'=>json_encode($dimension['height']),               
                            'girth'=>$girth,     
                            'dimension_weight'=>$dimension_weight,
                            'cubic_ft'=>$cubic_ft,
                            'shipping_warehouse'=> '' ,               'shipping_warehouse_id' => '' , 
                            'recv_warehouse'=> '' ,                   'recv_warehouse_id'=> '' ,
                            'remark'=> '' ,                           'product_description'=>$description ,
                            'commodity'=> $commodity,                 'local_currency_code'=> $currency,
                            'declared_value_lc'=> $package_value,     'declared_value_usd'=> $package_value_usd,
                            'country_of_export'=> $country_export ,   'hts_number'=> $hts,
                            'cust_ref'=>json_encode($customer_ref_info),
                            'sender_info'=>json_encode($sender_arr),              'recv_info'=>json_encode($recv_arr),
                            'recv_original_info'=>json_encode($recv_original),
                            'service_req'=>json_encode($service_info),            'insurance_info'=>json_encode(''),
                            'country_origin'=>$country_origin,                    'country_export'=>$country_export,  
                            'facility_id'=> $facility_id,                         'zone_id'=>  $zone_code,         
                            'facility_info'=>json_encode($facility_info),         'rate_info'=> json_encode($final_rate),
                            'carrier_info'=>json_encode($providerinfo),           'cost_rate_info'=> json_encode($final_cost_arr),
                            'cost_carrier_info'=>json_encode($providerinfo_cost), 'other'=> '' ,
                            'label_path'=> '' ,                             'label_filename'=> '' ,
                            'label_type'=> '' ,                             'parm_label_id' => $label_format ,
                            'parm_label_layout_id'=> $label_layout ,        'parcel_status_id' => 10,       
                            'tracking_no'=>'',  
                            );

                        $parcel_id = $this->parcel_model->create_parcel($data);
                        

                        if($parcel_id==false)
                        {
                            $status = false;     
                            $message[] = trans('l_e_parcel_create_01');
                        }
                        else 
                         {   
                            $data_history=array(    'parcel_history_id'=>0,     'parcel_id'=>$parcel_id,    
                                                    'parcel_status_id'=>10,     'comment'=>''           );
                            $data_tracking=array(    'parcel_history_tracking_id'=>0,        
                                                    'parcel_status_item_id'=>1,     'comment'=>'',    'notity'=>0  );

                            $update_status = $this->parcel_model->add_parcel_history($data_history, $data_tracking);
                            if($update_status==FALSE)
                              {
                                    $status = false;     
                                    $message[] = trans('l_e_parcel_create_04');   
                              }

                         }  
                  } // end status check       

        /************************************************************************************************************/
        /*  Create Parcel - end            */        
        /************************************************************************************************************/


        /************************************************************************************************************/
        /*  Generate Label - start            */        
        /************************************************************************************************************/
                if($status==TRUE) // if not error proceed with label  
                 {

                    $facility_additional_info = json_decode( $facility_info['additional_info'], TRUE);  
                    $facility_additional_info = $facility_additional_info[$providerinfo['code']] ;
                    
                    // generate tracking code
                    $track_01 = '420';
                    $track_02 = $recv_arr['recv_zip_code'];
                    $track_03 = $facility_additional_info['usps_app_identifier'].$providerinfo['service_type_code'].$facility_additional_info['usps_mid'].str_pad($parcel_id,11,'0', STR_PAD_LEFT);
                    $checkcode = $track_03.'X';
                    $check=$this->checkmod10($checkcode);   
                    $track_03 = $track_03.$check;
                    $label_arr = json_decode($providerinfo['label_info'],true);


                    $rec_addr_full = $recv_arr['recv_addr1'];
                    if($recv_arr['recv_addr2']!="")
                        $rec_addr_full.='<br>'.$recv_arr['recv_addr2']; 
                    
                    $addr_arr = array(
                        'rtn_addr'=> $facility_info["sender_name"].'<br/>'. $facility_info["rtn_addr1"].'<br/>'.$facility_info["rtn_addr_city"].', '.$facility_info["rtn_addr_state"].' '.$facility_info["rtn_addr_zip"],
                        'recv_name'=>$recv_arr['recv_name'],
                        'recv_addr'=>$rec_addr_full,
                        'recv_city'=>$recv_arr['recv_city'],
                        'recv_state'=>$recv_arr['recv_state'],
                        'recv_country'=>$recv_arr['recv_country'],
                        'recv_zip'=>$recv_arr['recv_zip_code'],
                        'recv_zip4'=>$recv_arr['recv_zip4_code'],
                        'barcode1'=>$track_01,'barcode2'=>$track_02,'barcode3'=>$track_03
                        );                

                    // tracking number
                    
                    $temp = uniqid($parcel_id, true);
                    $filename = md5($temp).'.pdf';
                    
                    $label_status = $this->generate_label(array_merge($label_arr,$addr_arr),$filename);   
                    $filename_rtn = $filename;
                    $file_type ="PDF";
                    
                    if( $label_status==FALSE )
                      {
                            $status = false;     
                            $message[] = trans('l_e_label_pdf');  
                      }  
                 }   // end status checking 

            /** update parcel ******************************************************************************/
                if($status==TRUE) 
                 {   
                        $data_parcel=array( 'label_path'=>site_url().C_LABEL_PATH,     
                                            'label_filename'=>$filename,            'label_type'=>$file_type, 
                                            'tracking_no'=>$track_01.$track_02.$track_03 
                            );
                        $this->parcel_model->update_parcel($data_parcel,$parcel_id);
                  }   

           
        /************************************************************************************************************/
        /*  Generate Label - end            */        
        /************************************************************************************************************/

        /************************************************************************************************************/
        /*  Generate respond for last mile - start            */        
        /************************************************************************************************************/
                if($status==TRUE && $service_code =="01000" ) 
                 {   
                    $response[]=array(
                        "request_code"=>$service_code,
                        'request_name'=> $txcd_item[$service_code]['title'.'_'.$header_info['data']['lang']],
                        'package_no'=>$rec_no,               
                        'created_at'=>   date('Y-m-d H:i:s') .' '.date_default_timezone_get(),
                        'tracking_number'=>$track_03,
                        'is_return_label'=>'N',
                        "rma_number"=>'',
                        "is_international"=> 'N',
                        "voided"=> 'N',
                        "voided_at"=> "",
                        "label_format"=> "pdf",
                        "label_layout"=> "4x6",
                        "label_download"=> site_url().C_LABEL_PATH.$filename, 
                        "trackable"=> "Y",
                        "origin_zipcode"=>$facility_info["entry_zipcode"], 
                        "destination_zipcode"=>$recv_arr['recv_zip_code'], 
                        "zone"=>$zone_code,
                        "chargeable_weight"=>round($chargeable_weight,2),               
                        "carrier_name"=>strtoupper($providerinfo['code']),
                        "mail_class"=>strtoupper($providerinfo['name']),
                        "service_type"=>strtoupper($providerinfo['service_type_code']),
                        "service_cost"=>$final_rate[$customer_level_id],
                      );

                    
                 }      

        /************************************************************************************************************/
        /*  Generate respond for last mile - end            */        
        /************************************************************************************************************/

        /************************************************************************************************************/
        /*  Generate order item for last mile - start            */        
        /************************************************************************************************************/
                if( $status == true )
                  { 
                        // service code 1 
                        $total=$total+$final_rate[$customer_level_id];
                        $subtotal=$subtotal+$final_rate[$customer_level_id];                       
                        // service code 1
                        $desc= trans('l_measurement').': '.$dimension['length'][$dimension_unit].$dimension_unit.' x '.$dimension['width'][$dimension_unit].$dimension_unit.' x '.$dimension['height'][$dimension_unit].$dimension_unit.'<br/>'.trans('l_weight').': '.$mass[$weight_unit].$weight_unit;
                        $data_order = array('id'=>0,        'order_id'=>$order_id,      'txcd'=>$txcd_item[$service_code]['txcd'],
                              'parcel_id'=> $parcel_id,     'name_en'=> $txcd_item[$service_code]['title_en'],               
                              'name_cn'=> $txcd_item[$service_code]['title_cn'],    
                              'description_en'=> $desc,          'description_cn'=> $desc ,       
                              'quantity'=>1,
                              'price'=>$final_rate[$customer_level_id],  
                              'total'=> $final_rate[$customer_level_id],                'tax'=>0,
                              'created_at'=>date('Y-m-d H:i:s'),    'created_by'=>0, 
                              'updated_at'=>date('Y-m-d H:i:s'),    'updated_by'=>0
                           );

                        $order_item_id = $this->parcel_model->create_order_item($data_order);
                        if($order_item_id===FALSE)
                        {
                            $status = false;     
                            $message[] = trans('l_e_parcel_create_02');       
                        }      
                  } 

        /************************************************************************************************************/
        /*  Generate order item for last mile - end            */        
        /************************************************************************************************************/




    /********************************************************************************************************/    
               } // end of last mile      

    /************************************************************************************************************/
    /*  Last mile serive 01000 - end            */        
    /************************************************************************************************************/

    /************************************************************************************************************/
    /*  Insurance service 08000 - start            */        
    /************************************************************************************************************/

                $insurance_info = array();
                
                // Insurance service
                if( $status==true && $service_code =="08000" )
                  {      

                        $insured_value = ( !empty($item['insured_value'])  ) ? $item['insured_value'] : '';   
                    
                        if(is_array($insured_value)) 
                         {  
                            if( $insured_value['insurance_provider'] = "" ) 
                             {
                                $status = false;     
                                $message[] = trans('l_e_insurance_provider');
                             }
                            if( $insured_value['currency'] ="" || strtoupper($insured_value['currency']) != "USD" ) 
                             {
                                $status = false;     
                                $message[] = trans('l_e_insurance_currency');
                             }
                            if( $insured_value['amount'] = "" )  
                             {
                                $status = false;     
                                $message[] = trans('l_e_insurance_amount');
                             }
                            
                            $insurance=array( 'currency'=>'usd', 'amount'=>0); // temporaly set to 0
                         }

                  } // end if status  
        
        /************************************************************************************************************/
        /*  Generate respond for insurance - start            */        
        /************************************************************************************************************/
 
                if($status==TRUE && $service_code =="08000" ) 
                 {   




                    $response[]=array(
                        "request_code"=>$service_code,
                        'request_name'=> $txcd_item[$service_code]['title'.'_'.$header_info['data']['lang']],
                        'insurance_provider'=>$insured_value['insurance_provider'],
                        'insured_value'=>array(     'currency'=>$insured_value['currency'], 
                                                    'amount'=> $insured_value['amount']   ),
                        'insurance_cost'=>array(    'currency'=>$insurance['currency'], 
                                                    'amount'=> $insurance['amount']       )  
                      );
                 }      

        /************************************************************************************************************/
        /*  Generate order item for insurance - start            */        
        /************************************************************************************************************/
                // update order item 
                if( $status == true && $service_code =="08000" )
                  { 
                        
                        // service code 1 
                        $total=$total+$insurance['amount'];
                        $subtotal=$subtotal+$insurance['amount'];
                        // service code 1
                        $desc= $insured_value['insurance_provider'].' insurance charges</br>Insured value: '.$insured_value['currency'].'-'.$insured_value['amount'];
                        $data_order = array('id'=>0,        'order_id'=>$order_id,      'txcd'=>$txcd_item[$service_code]['txcd'],
                              'parcel_id'=> $parcel_id,     'name_en'=> $txcd_item[$service_code]['title_en'],               
                              'name_cn'=> $txcd_item[$service_code]['title_cn'],    
                              'description_en'=> $desc,          'description_cn'=> $desc ,       
                              'quantity'=>1,
                              'price'=>$insurance['amount'],  
                              'total'=>$insurance['amount'],                'tax'=>0,
                              'created_at'=>date('Y-m-d H:i:s'),    'created_by'=>0, 
                              'updated_at'=>date('Y-m-d H:i:s'),    'updated_by'=>0
                           );

                        $order_item_id = $this->parcel_model->create_order_item($data_order);
                        if($order_item_id===FALSE)
                        {
                            $status = false;     
                            $message[] = trans('l_e_parcel_create_02');       
                        }      
                  } 

        /************************************************************************************************************/
        /*  Generate order item for insurance - end            */        
        /************************************************************************************************************/

    /************************************************************************************************************/
    /*  Insurance service 08000 - end            */        
    /************************************************************************************************************/

              } // end foreach service loop     

    /************************************************************************************************************/
    /*  End Loop of Service     */        
    /************************************************************************************************************/
 
                // check balance     
                if( $status == true )
                  { 
                  
                    $balance = 30000; // testing data 

                    if($balance<$final_rate[$customer_level_id])
                      {
                        $status = false;     
                        $message[] = trans('l_e_insufficient_balance');
                      }
                  }  


    /************************************************************************************************************/
    /*  Loop Parcel Item - start      */        
    /************************************************************************************************************/
                if( $status == true )
                  { 
                    if(isset( $item['package_content'] ) && count($item['package_content'])>0 )
                      {
                            foreach ($item['package_content'] as $itemKey=>$pitem)
                             {  $data = array (    
                                      'parcel_item_id'=>0,                  'parcel_id' =>$parcel_id,
                                      'item_no'=>$itemKey,                  'item_desc'=>$pitem['item_desc'],
                                      'commodity_desc'=>$pitem['commodity_desc'],
                                      'total_quantity'=>$pitem['total_quantity'],
                                      'item_gross_weight'=>$pitem['item_gross_weight'],          
                                      'total_gross_weight'=>$pitem['total_gross_weight'],      
                                      'item_net_weight'=>$pitem['item_net_weight'],         
                                      'total_net_weight'=>$pitem['total_net_weight'],        
                                      'declared_currency'=>$pitem['declared_value']['currency'],       
                                      'declared_item_value'=>$pitem['declared_value']['item_value'],     
                                      'declared_total_value'=>$pitem['declared_value']['total_value'],    
                                      'country_origin'=>$pitem['country_origin'],          
                                      'country_export'=>$pitem['country_export'],         
                                      'country_import'=>$pitem['country_import'],         
                                      'import_country_hts_code'=>$pitem['import_country_hts_code'], 
                                      'export_country_hts_code'=>$pitem['export_country_hts_code'], 
                                      'created_at'=>date('Y-m-d H:i:s'),    'created_by'=>0, 
                                      'updated_at'=>date('Y-m-d H:i:s'),    'updated_by'=>0
                                  );
                                $this->parcel_model->create_parcel_item($data);
                             } 
                      }
                  }  

    /************************************************************************************************************/
    /*  Loop Parcel Item - end      */        
    /************************************************************************************************************/

                // create order item // need to loop for service 
                

            // need to loop small items       


    /************************************************************************************************************/
    /*  generate response - start      */        
    /************************************************************************************************************/

            // generate response 
                if($status==TRUE) 
                 {   
                    // generate return message 
                    $rtnarr[$rec_no]=array(
                        'status'=>'S',
                        'weight'=>array( 
                            'unit'=>'lbs', 
                            'package_gross_weight'=>$mass['lbs'], 
                            'package_dimensional_weight'=>round($dimension_weight,2)
                           ),
                        'dimensions'=>array(
                            'unit'=>'in',
                            'length'=>round($dimension['length']['in'],2),
                            'width'=>round($dimension['width']['in'],2),
                            'height'=>round($dimension['height']['in'],2),
                            'length_plus_girth'=> round($dimension['length']['in']+$girth,2),
                            'cubic_ft'=>round($cubic_ft,2)
                           ),
                        'total_service_cost'=>array(
                             "currency"=>"usd",
                             'amount'=>$final_rate[$customer_level_id],
                           ),
                        "customer_reference"=>$customer_ref_info,
                        "service_request"=> $response,

                        //'record_no'=>$record_no,                          
                        //'tracking_code'=>$track_03,
                        //'message'=>$message,
                        //'rate'=>$final_rate[$customer_level_id],
                        //'rate'=>json_encode($final_rate),    
                        //'cost_rate'=>json_encode($final_cost_arr),    
                        //'zone'=>$zone_code,
                        //'entry_zipcode'=> $facility_info['entry_zipcode'],
                        //'service_charges'=>$service_rate,
                        //'label_link'=>site_url().C_LABEL_PATH.$filename_rtn, 
                       
                      ); 
                 }
                else 
                 {  
                    // error message 
                    $rtnarr[$rec_no]=array( 'record_no'=>$record_no,     'status'=>'E',      'message'=>$message,
                            'customer_reference'=>$customer_ref_info );

                    // reverse posting 
                    // delete all posted parcel 
                    // reverse parcel master and history 
                    // reverse order item / 
                    // reverse total amount for order header
                    

                    $total=$total-$subtotal;
                    $this->parcel_model->reverse_parcel($parcel_id);
            
                 }     

    /************************************************************************************************************/
    /*  generate response - end      */        
    /************************************************************************************************************/
    
            }  // end for each 

            // update order header if order total freater then zero 
            if($total>0)
            { 
                $data_order=array(  'invoice_no'=>$order_id,    'total'=>$total,    'order_status_id'=>1  );
                $order_id = $this->parcel_model->update_order($data_order, $order_id);
            }
            else 
            {
                $isError=TRUE;
                         
            }    

      } // end if json no error 

    if($isError)
     {  
        $this->db->trans_rollback();
        if(count($rtnarr) == 0)
            $rtnarr[] = array('status'=>'E', 'message'=>$message); 
        
        $rtn_array = array('packages'=>$rtnarr);
        $this->response( $rtn_array, 500 );


     }
    else  
     {      
        $this->db->trans_complete();
        $rtn_array = array('packages'=>$rtnarr);
        $this->response($rtn_array , 200 );
     }

 }













/***************************************************//*













public function create2_post()
 {
    $header = getallheaders();

    $p_code = ( !empty($header['p_code']) ) ? trim($header['p_code']) : ''; 
    $api_key = ( !empty( $header['api_key'] ) ) ? trim($header['api_key']) : ''; 
    $branch = ( !empty( $header['branch'] ) ) ? trim($header['branch']) : ''; 
    $lang = ( !empty( $header['lang'] ) ) ? trim($header['lang']) : 'en'; 
    $isError = FALSE;
    if($lang=='cn')
        $this->lang->load(array('api/api.php','api/parcel.php'),'chinese');

    $rtnarr = array();
    $data = json_decode(file_get_contents('php://input'), true);

    if( empty($p_code) || empty($branch) || empty($api_key) )
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key_require');
      }


    $customer_info = $this->parcel_model->checkHash($p_code,$branch, $api_key);
    if($customer_info===FALSE)
      {
        $isError=TRUE;     
        $message[] = trans('l_e_api_key');
      }        
    else 
     {  
        $customer_id = $customer_info['customer_id']; 
        $secret_key = $customer_info['secret_key'];
        $customer_level_id = $customer_info['customer_level_id'];
        $customer_name = $customer_info['customer_level_id'];
        $customer_email = ' ';
        $customer_contact= ' ';
        $payment_company= ' ';
        $payment_firstname= 'fname';
        $payment_lastname = ' ';
        $payment_addr1 = ' ';
        $payment_addr2   = ' ';
        $payment_city= ' ';
        $payment_city_id= ' ';
        $payment_postcode= ' ';
        $payment_state= ' ';
        $payment_state_id= ' ';
        $payment_country= ' ';
        $comment= ' ';
        $total= 0;
        $order_status_id=0;
        $created_at= 'CURRENT_TIMESTAMP';     
        $created_by = 0;
        $updated_at= 'CURRENT_TIMESTAMP';     
        $updated_by = 0;
     }  

    if( !$isError)
    {    
        // create order record 
        $this->db->trans_start();
        // write to oder records 
        $total = '';

        $data_order=array('order_id'=>0,             'invoice_prefix'=>C_INVOICE_PRE,
            'customer_id'=>$customer_id,            'customer_branch_code'=>$branch,          'customer_level_id'=>$customer_level_id,
            'customer_name'=>$customer_name,        'customer_email'=>$customer_email,        'customer_contact'=>$customer_contact,  
            'payment_company'=>$payment_company,    'payment_firstname'=>$payment_firstname,  'payment_lastname'=>$payment_lastname,
            'payment_addr1'=>$payment_addr1,        'payment_addr2'=>$payment_addr2,          'payment_city'=>$payment_city,
            'payment_city_id'=>$payment_city_id,    'payment_postcode'=>$payment_postcode,    'payment_state'=>$payment_state,
            'payment_state_id'=>$payment_state_id,  'payment_country'=>$payment_country,      'comment'=>$comment,
            'total'=>$total,                        'order_status_id'=>$order_status_id       

           
          );
        $order_id = $this->parcel_model->create_order($data_order);
        
        if($order_id===FALSE)
         {  $isError=TRUE;     
            $message[] = trans('l_e_api_key');
         }
        
        $txcd_info = $this->parcel_model->get_service_txcd(); 
        
        foreach($txcd_info as $fmtarr)
        {
            $txcd_item[$fmtarr['service_id']] = array('txcd'=>$fmtarr['txcd'],  
                    'title_en'=>$fmtarr['title_en'],    'title_cn'=>$fmtarr['title_cn'], 
                    'title_en'=>$fmtarr['title_en'],    'title_cn'=>$fmtarr['title_cn'] );
        } 

        if(!$isError)
        {     
            foreach ($data as $key=>$value)
            {   
                $status = true;  
                $message = array();
                // initialise field 
                $parcel_id =0;

                // length validation
                $length = ( !empty($value['length']) && is_numeric($value['length']) ) ? trim($value['length']) : '';
                if($length=="") {  
                    $status = false;     
                    $message[] = trans('l_e_length'); }  
                
                // width validation
                $width = ( !empty($value['width']) && is_numeric($value['width']) ) ? trim($value['width']) : '';
                if($width=="")  {  
                    $status = false;     
                    $message[] = trans('l_e_width');  }  

                // height validation    
                $height = ( !empty($value['height']) && is_numeric($value['height']) ) ? trim($value['height']) : '';
                if($height=="") {  
                    $status = false;     
                    $message[] = trans('l_e_height'); }    
                
                // dimension unit validation    
                $dimension_unit = ( !empty($value['dimension_unit']) ) ? trim($value['dimension_unit']) : '';
                if($dimension_unit=="") {   
                    $status = false;    
                    $message[] = trans('l_e_dimension_unit');  }    
                else if ( !$this->chk_field_table('gb_parm_dimension_unit','code',$dimension_unit,'rec_status=1') )
                    {   $status = false;   $message[] = trans('l_e_dimension_unit');       } 
                
                // weight validation
                $weight = ( !empty($value['weight']) && is_numeric($value['weight']) ) ? trim($value['weight']) : '';
                if($weight=="") {  
                    $status = false;     
                    $message[] = trans('l_e_weight');  }
                
                // weight unit validation     
                $weight_unit = ( !empty($value['weight_unit'])  ) ? trim($value['weight_unit']) : '';
                if($weight_unit=="") {   
                    $status = false;    
                    $message[] = trans('l_e_weight_unit');  }    
                else if ( !$this->chk_field_table('gb_parm_weight_unit','code',$weight_unit,'rec_status=1') )
                    {   $status = false;   $message[] = trans('l_e_weight_unit');       } 

                // description validation     
                $description = ( !empty($value['description']) ) ? trim($value['description']) : '';

                // currency validation     
                $currency = ( !empty($value['currency'])  ) ? trim($value['currency']) : '';
                
                // package value            
                $package_value = ( !empty($value['package_value']) && is_numeric($value['package_value']) ) ? trim($value['product_value']) : '';

                // package value in usd           
                $package_value_usd = ( !empty($value['package_value_usd']) && is_numeric($value['package_value_usd']) ) ? trim($value['package_value_usd']) : '';
     
                // commodity
                $commodity = ( !empty($value['commodity']) && is_numeric($value['commodity']) ) ? trim($value['commodity']) : '';        
                //hts
                $hts = ( !empty($value['hts'])  ) ? trim($value['hts']) : '';
                
                //country origin
                $country_origin = ( !empty($value['country_origin']) && is_numeric($value['country_origin']) ) ? trim($value['country_origin']) : '';

                //country export 
                $country_export = ( !empty($value['country_export']) && is_numeric($value['country_export']) ) ? trim($value['country_export']) : '';
                
                // customer reference        
                $cust_ref1 = trim($value['cust_ref1']);
                $cust_ref2 = trim($value['cust_ref2']);
                $cust_ref3 = trim($value['cust_ref3']);
                $cust_ref4 = trim($value['cust_ref4']);
                $cust_ref5 = trim($value['cust_ref5']);

                // service req 1
                $service_req1 = ( !empty($value['service_req1'])  ) ? trim($value['service_req1']) : '';
                if ( !$this->chk_field_table('gb_parm_service_type','id',$service_req1,'') )
                    {   $status = false;  $message[] = trans('l_e_service_req1');          }

                // service req 2
                $service_req2 = $value['service_req2'];

                // extra service req 1
                $ex_service_req1 = ( !empty($value['ex_service_req1'])  ) ? trim($value['ex_service_req1']) : '';
                if ( !$this->chk_field_table('gb_parm_service_type','id',$ex_service_req1,'') )
                    {   $status = false;  $message[] = trans('l_e_ex_service_req1');          }

                // extra service req 2
                $ex_service_req2 = $value['ex_service_req2'];

                // label format 
                $label_format = ( !empty($value['label_format'])  ) ? trim($value['label_format']) : '';
                if ( !$this->chk_field_table('gb_parm_label','id',$label_format,'') )
                    {   $status = false;  $message[] = trans('l_e_label_format');          }        
 
                // label layout
                $label_layout = ( !empty($value['label_layout'])  ) ? trim($value['label_layout']) : '';
                if ( !$this->chk_field_table('gb_parm_label_layout','id',$label_layout,'') )
                    {   $status = false;  $message[] = trans('l_e_label_layout');          }        
                
                // send firm 
                $send_firm = ( !empty($value['send_firm'])  ) ? trim($value['send_firm']) : '';
                
                // send name
                $send_name = ( !empty($value['send_name'])  ) ? trim($value['send_name']) : '';
                if($send_name == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_name');  }  

                // address
                $send_addr1 = ( !empty($value['send_addr1'])  ) ? trim($value['send_addr1']) : '';
                if($send_addr1 == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_addr1');  }  

                $send_addr2 = ( !empty($value['send_addr2'])  ) ? trim($value['send_addr2']) : '';
                
                // city
                $send_city = (  !empty($value['send_city'])  ) ? trim($value['send_city']) : '';
                if($send_city == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_city');  }         

                // state    
                $send_state = ( !empty($value['send_state'])  ) ? trim($value['send_state']) : '';
                if($send_state == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_state');  }         

                // zip code    
                $send_zip_code = ( !empty($value['send_zip_code'])  ) ? trim($value['send_zip_code']) : '';   
                if($send_zip_code == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_zip_code');  }         
                
                $send_zip4_code = ( !empty($value['send_zip4_code'])  ) ? trim($value['send_zip4_code']) : '';
                
                $send_country = ( !empty($value['send_country'])  ) ? trim($value['send_country']) : '';
                if($send_country == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_send_country');  }        

                $send_email = ( !empty($value['send_email'])  ) ? trim($value['send_email']) : '';   
                $send_sms = ( !empty($value['send_sms'])  ) ? trim($value['send_sms']) : '';   
                
                $recv_firm = ( !empty($value['recv_firm'])  ) ? trim($value['recv_firm']) : '';
                $recv_name = ( !empty($value['recv_name'])  ) ? trim($value['recv_name']) : '';
                if($recv_name == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_name');  }  

                $recv_addr1 = ( !empty($value['recv_addr1'])  ) ? trim($value['recv_addr1']) : '';
                if($recv_addr1 == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_addr1');  }         

                $recv_addr2 = ( !empty($value['recv_addr2'])  ) ? trim($value['recv_addr2']) : '';
                $recv_city = ( !empty($value['recv_city'])  ) ? trim($value['recv_city']) : '';
                if($recv_city == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_city');  }

                $recv_state = ( !empty($value['recv_state'])  ) ? trim($value['recv_state']) : '';
                if($recv_state == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_state');  }                

                $recv_zip_code = ( !empty($value['recv_zip_code'])  ) ? trim($value['recv_zip_code']) : '';   
                if($recv_zip_code == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_zip_code');  }    

                $recv_zip4_code = ( !empty( $value['recv_zip4_code'])  ) ? trim($value['recv_zip4_code']) : '';   
                $recv_country = ( !empty($value['recv_country'])  ) ? trim($value['recv_country']) : '';   
                if($recv_country == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_recv_country');  }  
                           

                $recv_email = ( !empty($value['recv_email'])  ) ? trim($value['recv_email']) : '';   
                $recv_sms = ( !empty($value['recv_sms'])  ) ? trim($value['recv_sms']) : '';   

                $hashkey = ( !empty($value['hashkey'])  ) ? trim($value['hashkey']) : '';   
                if($hashkey == "")  {  
                    $status = false;     
                    $message[] = trans('l_e_hash_key');  }    
                
                //echo $hashkey;
                    
                $hash = md5($secret_key.$length.$width.$height);
                //echo '<br/>';
                //echo $hash;
                // check hasing info 
                if( $hash !== $hashkey )
                {
                    $status = false;     
                    $message[] = trans('l_e_hash_check');
                }
                
                // start parcer processing
                if($status==TRUE)
                  {
                    //  rearrange 
                    $dim = array($length, $width, $height);    
                    
                    rsort($dim,1);

                    $dimension = get_dimension_info($dim,$dimension_unit);
                    $mass = get_mass_info($weight,$weight_unit); 
                    
                    //Girth (G) = ( 2 x Height) + (2 x Width)
                    $girth = ( 2*$dimension['height']['in'] ) + ( 2*$dimension['width']['in'] );

                    $cubic_ft = $dimension['length']['ft']*$dimension['width']['ft']*$dimension['height']['ft'];
                    
                    $dimension_weight = ($dimension['length']['in']*$dimension['height']['in']*$dimension['width']['in'])/166;
                    // check zone 
                    $result = $this->parcel_model->get_zone($recv_zip_code); 
                 


                    $facility_id = $result[0]['facility_id'];
                    $zone_code = $result[0]['zone_code'];
                    $facility_info= array(
                         'facility_name'=>$result[0]['facility_name'],      'entry_type'=>$result[0]['entry_type'],
                         'entry_zipcode'=>$result[0]['entry_zipcode'],      'entry_zipcode4'=>$result[0]['entry_zipcode4'], 
                         'rtn_addr1'=>$result[0]['rtn_addr1'],              'rtn_addr_city'=>$result[0]['rtn_addr_city'],
                         'rtn_addr_state'=>$result[0]['rtn_addr_state'],    'rtn_addr_zip'=>$result[0]['rtn_addr_zip'], 
                         'sender_name'=>$result[0]['sender_name'],          'sender_email'=>$result[0]['sender_email'], 
                         'sender_sms'=>$result[0]['sender_sms'],            'additional_info'=>$result[0]['additional_info']
                        );     
                    
                    $final_rate = array();
                    $providerinfo = array();
                    //------------------------------------
                    // check price 
                    // get price for usps firstclass package service 
                    $final_cost_arr = array();
                    $providerinfo_cost = array();
                    

                    $rate_arr = array();
                    $cost_arr = array();
                

                    if( $dimension['length']['in'] <=22 && $dimension['width']['in'] <=18 && $dimension['height']['in'] <=15 && $mass['lbs']< 1 )
                        {      
                            $rate_arr = $this->parcel_model->get_firstclass_rate($mass['oz'],$zone_code);
                            $rate_arr = get_price_rate($rate_arr);
                            
                            if( count($final_rate)==0 || ( count($rate_arr)>0 && $rate_arr[$customer_level_id] < $final_rate[$customer_level_id] ) )
                             {
                                $final_rate = $rate_arr;
                                $providerinfo = $this->parcel_model->get_carrier_service_type(1);
                             }     
                            // cost    
                            if( count($final_cost_arr)==0 || ( count($rate_arr)>0 && $rate_arr['cost'] < $final_cost_arr['cost'] ) )
                             {
                                $final_cost_arr =  $rate_arr;
                                $providerinfo_cost = $this->parcel_model->get_carrier_service_type(1);
                             }      
                        }   

                    // check commercial cubic        
                    if( ($dimension['length']['in']+$girth)<=108 && $cubic_ft <= 0.5 && $mass['lbs'] <= 20 )
                        { 
                            $rate_arr = $this->parcel_model->get_comm_cubic_rate($cubic_ft,$zone_code);
                            $rate_arr = get_price_rate($rate_arr);
                            
                            if( count($final_rate)==0 || ( count($rate_arr)>0 && $rate_arr[$customer_level_id]<$final_rate[$customer_level_id] ) )
                             {
                                $final_rate = $rate_arr;
                                $providerinfo = $this->parcel_model->get_carrier_service_type(3);

                                //$providerinfo = array( 'type'=>"C", 'rate_ind'=>'CP', 'mailclass' =>'PM'  );      
                             }    
                            // cost    
                            if( count($final_cost_arr)==0 || ( count($rate_arr)>0 && $rate_arr['cost'] < $final_cost_arr['cost'] ) )
                             {
                                $final_cost_arr =  $rate_arr;
                                $providerinfo_cost = $this->parcel_model->get_carrier_service_type(1);
                             }                
                        }   
                    
                    // check priority mail commercial plus         
                    if( ($dimension['length']['in']+$girth)<=108  && $mass['lbs'] <= 70 )
                        {   
                            if( $cubic_ft <= 1)
                            {   $rate_arr = $this->parcel_model->get_comm_plus_rate($mass['lbs'],$zone_code);
                                //echo $this->db->last_query();
                            }
                            else
                            {      
                                $rate_arr = $this->parcel_model->get_comm_plus_rate( max($dimension_weight,$mass['lbs'] ),$zone_code);   
                            } 
                            
                            $rate_arr = get_price_rate($rate_arr);

                            if( count($final_rate)==0 || ( count($rate_arr)>0 && $rate_arr[$customer_level_id]<$final_rate[$customer_level_id] ) )
                             {
                                $final_rate = $rate_arr;
                                $providerinfo = $this->parcel_model->get_carrier_service_type(2);
                                //$providerinfo = array( 'type'=>"C", 'rate_ind'=>'SP', 'mailclass' => 'PM'  );      
                             }                         
                        
                            // cost    
                            if( count($final_cost_arr)==0 || ( count($rate_arr)>0 && $rate_arr['cost'] < $final_cost_arr['cost'] ) )
                             {
                                $final_cost_arr =  $rate_arr;
                                $providerinfo_cost = $this->parcel_model->get_carrier_service_type(1);
                             } 

                        }   

                    $providerinfo = $providerinfo[0];   
                    $providerinfo_cost = $providerinfo_cost[0];

                    if( count($final_rate)==0 )
                        {
                            $status = false;     
                            $message[] = trans('l_e_rate_emtpy');
                        }    
     
                  }
                    

                // create parcel  
                if($status==TRUE) // if not error 
                {   

                    $sender_arr = array(
                        'send_firm'=>$send_firm,            'send_name'=>$send_name,            'send_addr1'=>$send_addr1, 
                        'send_addr2'=>$send_addr2,          'send_city'=>$send_city,            'send_state'=>$send_state,
                        'send_zip_code'=>$send_zip_code,    'send_zip4_code'=>$send_zip4_code,  'send_country'=>$send_country,  
                        'send_email'=>$send_email,          'send_sms'=>$send_sms  );

                    $recv_arr = array(
                        'recv_firm'=>$recv_firm,            'recv_name'=>$recv_name,            'recv_addr1'=>$recv_addr1, 
                        'recv_addr2'=>$recv_addr2,          'recv_city'=>$recv_city,            'recv_state'=>$recv_state,
                        'recv_zip_code'=>$recv_zip_code,    'recv_zip4_code'=>$recv_zip4_code,  'recv_country'=>$recv_country,  
                        'recv_email'=>$recv_email,          'recv_sms'=>$recv_sms  );
                    
                    $service_req_arr    = array('service_req1'=>$service_req1,            'service_req2'=>$service_req2    );
                    $ex_service_req_arr = array('ex_service_req1'=>$ex_service_req1,      'ex_service_req2'=>$ex_service_req2 );
                    
                     // Generate tracking number
                    $data = array(  'parcel_id'=>0,     'customer_id'=>$customer_id,        'branch'=>$branch,
                      'bag_id'=> '' ,             'carton_id'=> '' ,                  'box_id'=> '' ,
                      'container_id'=> '' ,       'mawb'=> '' ,                       'hawb'=> '' ,
                      'weight_lbs'=>$mass['lbs'], 'weight_json'=>json_encode($mass),  'length_in'=>$dimension['length']['in'],
                      'length_json' =>json_encode($dimension['length']),              'width_in'=>$dimension['width']['in'] ,
                      'width_json'=>json_encode($dimension['width']),                 'height_in'=>$dimension['height']['in'] ,
                      'height_json'=>json_encode($dimension['height']),               'girth'=>$girth,     
                      'dimension_weight'=>$dimension_weight,
                      'cubic_ft'=>$cubic_ft,
                      'shipping_warehouse'=> '' ,               'shipping_warehouse_id' => '' , 
                      'recv_warehouse'=> '' ,                   'recv_warehouse_id'=> '' ,
                      'remark'=> '' ,                           'product_description'=>$description ,
                      'commodity'=> $commodity,                 'local_currency_code'=> $currency,
                      'declared_value_lc'=> $package_value,     'declared_value_usd'=> $package_value_usd,
                      'country_of_export'=> $country_export ,   'hts_number'=> $hts,
                      'internal_tracking_1'=> '' ,              'internal_tracking_2'=> '' ,
                      'internal_tracking_3' => '' ,             'internal_tracking_4'=>'' ,  'internal_tracking_5'=>'',             
                      'cust_ref_1'=>$cust_ref1,                 'cust_ref_2'=> $cust_ref2 ,
                      'cust_ref_3'=> $cust_ref3 ,               'cust_ref_4'=> $cust_ref4 ,             'cust_ref_5'=> $cust_ref5 ,
                      'sender_info'=>json_encode($sender_arr),              'recv_info'=>json_encode($recv_arr),
                      'service_req'=>json_encode($service_req_arr),         'ex_service_req'=>json_encode($ex_service_req_arr),
                      'country_origin'=>$country_origin,                    'country_export'=>$country_export,  
                      'facility_id'=> $facility_id,                         'zone_id'=>  $zone_code,         
                      'facility_info'=>json_encode($facility_info),         'rate_info'=> json_encode($final_rate),
                      'carrier_info'=>json_encode($providerinfo),           'cost_rate_info'=> json_encode($final_cost_arr),
                      'cost_carrier_info'=>json_encode($providerinfo_cost),
                      'other'=> '' ,
                      'label_path'=> '' ,
                      'label_filename'=> '' ,
                      'label_type'=> '' ,
                      'parm_label_id' => $label_format ,
                      'parm_label_layout_id'=> $label_layout ,
                      'parcel_status_id' => 10,
                      'tracking_no'=>'',  

                    ); // end of array 
                   
                    $parcel_id = $this->parcel_model->create_parcel($data);


                    if($parcel_id==false)
                    {
                        $status = false;     
                        $message[] = trans('l_e_parcel_create_01');
                    }
                    
                    $data_history=array(        'parcel_history_id'=>0,     'parcel_id'=>$parcel_id,    
                                                'parcel_status_id'=>10,     'comment'=>''           );

                    $data_tracking=array(       'parcel_history_tracking_id'=>0,        
                                                'parcel_status_item_id'=>1,     'comment'=>'',    'notity'=>0  );

                    $update_status = $this->parcel_model->add_parcel_history($data_history, $data_tracking);
                    if($update_status==FALSE)
                    {
                        $status = false;     
                        $message[] = trans('l_e_parcel_create_04');   
                    }
                }  
          
                //---------------------------------------------------------------------------------------
                //  check customer balance  -------------------------------------------------------------
                //---------------------------------------------------------------------------------------
                $balance = 30000; // testing data 

                if($balance<$final_rate[$customer_level_id])
                {
                        $status = false;     
                        $message[] = trans('l_e_insufficient_balance');
                }



                // create order item   
                if($status==TRUE) // if not error 
                 {  // service code 1 
                    $total=$total+$final_rate[$customer_level_id];
                    $service_rate=0;
                    // service code 1
                    $desc= trans('l_measurement').': '.$dimension['length'][$dimension_unit].$dimension_unit.' x '.$dimension['width'][$dimension_unit].$dimension_unit.' x '.$dimension['height'][$dimension_unit].$dimension_unit.'<br/>'.trans('l_weight').': '.$mass[$weight_unit].$weight_unit;

                    $data_order = array('id'=>0,        'order_id'=>$order_id,      'txcd'=>'9001',
                          'parcel_id'=> $parcel_id,     'name_en'=> $txcd_item[1]['title_en'],               
                          'name_cn'=> $txcd_item[1]['title_cn'],    
                          'description_en'=> $desc,          'description_cn'=> $desc ,       
                          'quantity'=>1,
                          'price'=>$final_rate[$customer_level_id],  
                          'total'=> $final_rate[$customer_level_id],                'tax'=>0
                       );

                    $order_item_id = $this->parcel_model->create_order_item($data_order);
                    if($order_item_id===FALSE)
                    {
                        $status = false;     
                        $message[] = trans('l_e_parcel_create_02');       
                    }    
                 }    

                if($status==TRUE && $service_req2!="") // if not error 
                 {  // service code 2
                    $service_price = 1;
                    $service_rate=$service_rate+$service_price;
                    // set to 1 dollar
                    $total=$total+$service_price;
                    
                    $desc='';
                    $data_order = array('id'=>0,                'order_id'=>$order_id,      
                          'txcd'=>'9002',
                          'parcel_id'=> $parcel_id,             
                          'name_en'=> $txcd_item[2]['title_en'],               
                          'name_cn'=> $txcd_item[2]['title_cn'],    
                          'description_en'=> $desc,          'description_cn'=> $desc ,       
                          'quantity'=>1,
                          'price'=> $service_price,             'total'=> $service_price,                
                          'tax'=>0
                       );
                    $order_item_id = $this->parcel_model->create_order_item($data_order);
                    if($order_item_id===FALSE)
                    {
                        $status = false;     
                        $message[] = trans('l_e_parcel_create_03');       
                    }    

                 }    

                if($status==TRUE && $ex_service_req1!="") // if not error 
                 {  // service code 3
                    $service_price = 2;
                    $service_rate=$service_rate+$service_price;
                    // set to 1 dollar
                    $total=$total+$service_price;
                    
                    $desc='';
                    $data_order = array('id'=>0,                'order_id'=>$order_id,      
                          'txcd'=>'9003',
                          'parcel_id'=> $parcel_id,             
                          'name_en'=> $txcd_item[3]['title_en'],               
                          'name_cn'=> $txcd_item[3]['title_cn'],    
                          'description_en'=> $desc,          'description_cn'=> $desc ,       
                          'quantity'=>1,
                          'price'=> $service_price,             'total'=> $service_price,                
                          'tax'=>0
                       );
                    $order_item_id = $this->parcel_model->create_order_item($data_order);
                    if($order_item_id===FALSE)
                    {
                        $status = false;     
                        $message[] = trans('l_e_parcel_create_03');       
                    }    

                 }     
                 
                if($status==TRUE && $ex_service_req2!="") // if not error 
                 {  // service code 3
                    $service_price = 3;
                    $service_rate=$service_rate+$service_price;
                    // set to 1 dollar
                    $total=$total+$service_price;
                    
                    $desc='';
                    $data_order = array('id'=>0,                'order_id'=>$order_id,      
                          'txcd'=>'9004',
                          'parcel_id'=> $parcel_id,             
                          'name_en'=> $txcd_item[4]['title_en'],               
                          'name_cn'=> $txcd_item[4]['title_cn'],    
                          'description_en'=> $desc,          'description_cn'=> $desc ,       
                          'quantity'=>1,
                          'price'=> $service_price,             'total'=> $service_price,                
                          'tax'=>0
                       );
                    $order_item_id = $this->parcel_model->create_order_item($data_order);
                    if($order_item_id===FALSE)
                    {
                        $status = false;     
                        $message[] = trans('l_e_parcel_create_03');       
                    }    

                 }

                if($status==TRUE) // if not error proceed with label  
                 {

                    $facility_additional_info = json_decode( $facility_info['additional_info'], TRUE);  
                    $facility_additional_info = $facility_additional_info[$providerinfo['code']] ;
                    
                    
                    // generate tracking code
                    $track_01 = '420';
                    $track_02 = $recv_arr['recv_zip_code'];
                    $track_03 = $facility_additional_info['app_identifier'].$providerinfo['service_type_code'].$facility_additional_info['mid'].str_pad($parcel_id,11,'0', STR_PAD_LEFT);

                    $checkcode = $track_03.'X';
                    $check=$this->checkmod10($checkcode);   
                    $track_03 = $track_03.$check;
                    
                     
                    
                    $label_arr = json_decode($providerinfo['label_info'],true);
                    
                    $rec_addr_full = $recv_arr['recv_addr1'];
                    if($recv_arr['recv_addr2']!="")
                        $rec_addr_full.='<br>'.$recv_arr['recv_addr2']; 
                    
                    $addr_arr = array(
                        'rtn_addr'=> $facility_info["sender_name"].'<br/>'. $facility_info["rtn_addr1"].'<br/>'.$facility_info["rtn_addr_city"].', '.$facility_info["rtn_addr_state"].' '.$facility_info["rtn_addr_zip"],
                        'recv_name'=>$recv_arr['recv_name'],
                        'recv_addr'=>$rec_addr_full,
                        'recv_city'=>$recv_arr['recv_city'],
                        'recv_state'=>$recv_arr['recv_state'],
                        'recv_country'=>$recv_arr['recv_country'],
                        'recv_zip'=>$recv_arr['recv_zip_code'],
                        'recv_zip4'=>$recv_arr['recv_zip4_code'],
                        'barcode1'=>$track_01,'barcode2'=>$track_02,'barcode3'=>$track_03
                        );                

                    // tracking number
                    
                    $temp = uniqid($parcel_id, true);
                    $filename = md5($temp).'.pdf';
                    
                    $label_status = $this->generate_label(array_merge($label_arr,$addr_arr),$filename);   
                    $filename_rtn = $filename;
                    
                    $file_type ="PDF";
                    //echo site_url().C_LABEL_PATH.$filename;

                    if( $label_status!==FALSE )
                      {    

                        if($label_format==1) // png
                        {
                            
                                
                                // convert pdf to png 
                                $status = false;     
                                $message[] = trans('l_e_label_png');

                                // if succeefull 
                                $filename_rtn = $filename;
                                $file_type = 'PNG';
                            //} 
                        }
                    

                      }
                    else 
                      {
                            $status = false;     
                            $message[] = trans('l_e_label_pdf');  
                      }  
                 }   // endif status error
                



                // update parcel
                if($status==TRUE) 
                 {   
                        $data_parcel=array(    'label_path'=>site_url().C_LABEL_PATH,     
                                               'label_filename'=>$filename,            'label_type'=>$file_type, 
                                               'tracking_no'=>$track_01.$track_02.$track_03 
                            );
                        $this->parcel_model->update_parcel($data_parcel,$parcel_id);
                  }    

                if($status==TRUE) 
                 {   
                    // generate return message 
                    $rtnarr[]=array(
                        'record_no'=>$key,                          'tracking_code'=>$track_03,
                        'status'=>'S',                              'message'=>$message,
                        'rate'=>$final_rate[$customer_level_id],
                        //'rate'=>json_encode($final_rate),    
                        //'cost_rate'=>json_encode($final_cost_arr),    
                        'zone'=>$zone_code,
                        'entry_zipcode'=> $facility_info['entry_zipcode'],
                        'service_charges'=>$service_rate,
                        'label_link'=>site_url().C_LABEL_PATH.$filename_rtn, 
                        'customer_ref'=>array($cust_ref1,$cust_ref2,$cust_ref3,$cust_ref4,$cust_ref5),
                      ); 
                 }
                else 
                 {
                    // error message 
                    $rtnarr[]=array( 'record_no'=>$key,     'status'=>'E',      'message'=>$message,
                            'customer_ref'=>array($cust_ref1,$cust_ref2,$cust_ref3,$cust_ref4,$cust_ref5) );

                    // reverse posting 
                    // delete all posted parcel 
                    // reverse parcel master and history 
                    // reverse order item / 
                    // reverse total amount for order header
                    
                    $total=$total-$service_rate-$final_rate[$customer_level_id];
                    $this->parcel_model->reverse_parcel($parcel_id);
            
                 } 

            } // end for    

            // update order header if order total greater than zero/. if == zero mean all the item got error and deleted
            if($total>0)
            { 
                $data_order=array(  'invoice_no'=>$order_id,    'total'=>$total,    'order_status_id'=>1  );
                $order_id = $this->parcel_model->update_order($data_order, $order_id);
            }
            else 
            {
                $isError=TRUE;
                         
            }    
        }  // end if iserror 

        // close order 
        
        if($isError)
         {
            $this->db->trans_rollback();
            $this->response( $rtnarr, 500 );
         }
        else  
         {   
            $this->db->trans_complete();
            $this->response( $rtnarr, 200 );
         }
    }
    else 
    {    
        $rtnarr[] = array('status'=>false, 'message'=>$message );
        $this->response( $rtnarr, 500 );
    }    
     

 }   
*/
private function chk_field_table($table,$field,$value,$where)
 {  
        $o='';
        $o.='select * from '.$table.' where '.$field.' = '.$this->db->escape($value).' ' ;
        
        if($where!="") $o.=' && '.$where.' ;';
        $query = $this->db->query($o  );
       
        if( count($query->result_array())>0 ) 
            return true;
        else 
            return false;
 }


    private function generate_label($data,$filename)
        {   
            ob_start();
            $params=array('P', 'px', 'USPS_LABEL_CO2', true, 'UTF-8', false);
            $this->load->library('pdf',$params);

            $this->pdf->setPageUnit('px');
            // turn off
            $this->pdf->setPrintHeader(false);
            $this->pdf->setPrintFooter(false);
            $this->pdf->SetAutoPageBreak(false);
            $fa = TCPDF_FONTS::addTTFfont(APPPATH.'/libraries/tcpdf_min/fonts/ArialCE.ttf',  'TrueTypeUnicode', '', 4);
            $fab = TCPDF_FONTS::addTTFfont(APPPATH.'/libraries/tcpdf_min/fonts/ArialCEBold.ttf',  'TrueTypeUnicode', '', 4);

            $this->pdf->setFont($fab);
            $this->pdf->SetFont('helvetica', 'B', 20, '', false);
            //service icon block 1 in = 25.4mm 

//foreach($data as $item)
//{
            $item = $data;  
            
            
            
            $this->pdf->AddPage();
            $this->pdf->setxy(0,0);
            $border_style = array('width' =>1, 'cap' => 'square', 'join' => 'mitter', 'dash' => '', 'color' => array(0, 0, 0));
            $this->pdf->rect(0,0,288,432,'D', array('all' => $border_style));
            $this->pdf->rect(0,0,288,72,'D', array('all' => $border_style));

            // row 1 ------------------------------------------------------------
            // text P box
            $this->pdf->rect(0,0,72,72,'D', array('all' => $border_style));
            //$this->pdf->SetFont('helvetica', 'B', 75, '', false);
            $this->pdf->setFont($fab, 'B', 75, '', false);
            $this->pdf->Cell(72, 72, $item['top_label'], 0, 0, 'C', 0, '', 0,true, 'T','M');
            
            // top right 

            // place holder white ox
            // right x 11.500
            $this->pdf->rect(170,14.5,88,36,'D', array('all' => $border_style));
         
            //$this->pdf->SetFont('helvetica', '', 6.5, '', false);
            $this->pdf->setFont($fa, '', 6.5, '', false);

            $this->pdf->MultiCell(88, 36, $item['mail_class'], 0, 'C', 0, 0, 170,16 , true,0, true, true, 34  );
 
            $this->pdf->MultiCell(90, 37, $item['cubic'], 0, 'C', 0, 0, 170,52 , true,0, true, true, 37  );
     
     
            // row 2 ------------------------------------------------------------
            // x = 0 y = inch / 3.175 

            $this->pdf->rect(0,72,288,22.5,'D', array('all' => $border_style));
            // spacer box 
            //$this->pdf->rect(0,72,288,4.5,'D', array('all' => $border_style));


            //$this->pdf->SetFont('helvetica', 'B', 17.5, '', false);
            $this->pdf->setFont($fab, 'B', 17.5, '', false);

            $this->pdf->MultiCell( 290,22.65625, $item['mail_name'], 0, 'C', 0, 0, 0,72.5 , true,0, true, true, 22.65625  );

            // spacer box 
            //$this->pdf->rect(0,90,288,4.5,'D', array('all' => $border_style));


            // row 3 ------------------------------------------------------------
            // x = 0 y = inch / 3.175 +  0.99218 = 4.16718 
            //$this->pdf->rect(0,94.5,288,200,'D', array('all' => $border_style));

            //$this->pdf->SetFont('helvetica', '', 8.5, '', false);
            $this->pdf->setFont($fa, '', 8.5, '', false);                
            $return_addr=$item['rtn_addr'];
            /*$return_addr='GLOBAL PARCEL SERVICE INC.<br/>';
            $return_addr.='1000 RIVERSIDE DR.<br/>';
            $return_addr.='KEASBEY NJ 08832<br/>';
            $return_addr.='';*/
            // box 1/4 inch
            //$this->pdf->rect(7,101.5,145,40,'D', array('all' => $border_style));
            $this->pdf->MultiCell( 145,45, $return_addr, 0, 'L', 0, 0, 4,100 , true,0, true, true, 40  );
            

            // 1/4 inch box 
            //$this->pdf->rect(7,141.5,145,18,'D', array('all' => $border_style));
            //$this->pdf->MultiCell( 200,15, 'WAIVER OF SIGNATURE REQUESTED', 0, 'L', 0, 0, 7,159 , true,0, true, true, 15  );
            //$this->pdf->rect(7,170,145,18,'D', array('all' => $border_style));

        // row 4 ------------------------------------------------------------
            // y  7.10093 + 0.488 = 7.58893
            //  height 4.16718  1" 5/16" inch
            //  width  10.31875 3" 1/4" inch
            
            // border    
            //$this->pdf->rect(36,188,234,94.5,'D', array('all' => $border_style));
            // xline
            $this->pdf->rect(36,188,12,3,'F', array('all' => $border_style), array(0, 
                0, 0) );
            // yline
            $this->pdf->rect(36,188,3,12,'F', array('all' => $border_style), array(0, 0, 0) );

             // xline
            $this->pdf->rect(258,279.5,12,3,'F', array('all' => $border_style), array(0, 
                0, 0) );
            // yline
            $this->pdf->rect(267,270.5,3,12,'F', array('all' => $border_style), array(0, 0, 0) );
            //$this->pdf->SetFont('helvetica', '', 10.5, '', false); // larger 10
            $this->pdf->setFont($fa, '', 10.5, '', false);


            $rec_addr= strtoupper($item['recv_name']).'<br/>';
            $rec_addr.=strtoupper($item['recv_addr']).'<br/>';
            $rec_addr.=strtoupper($item['recv_city']).' ';
            $rec_addr.=strtoupper($item['recv_state']).' ';
            $rec_addr.=strtoupper($item['recv_zip'].'-'.$item['recv_zip4']).'<br/>';
            $this->pdf->MultiCell( 216,76.5, $rec_addr, 0, 'L', 0, 0, 45,197 , true,0, true, true, 76.5  );

         // row 5 - bar code------------------------------------------------------------    
            //outer box
            $this->pdf->rect(0,295,288,108,'D', array('all' => $border_style)); 
            // thick link
            $this->pdf->rect(0,295,288,2.25,'F',array('all'=>$border_style),array(0,0,0));
            // white spece 1/32" 2.5
            //$this->pdf->rect(0,297.25,288,2.75,'D',array('all'=>$border_style));
            // white spece 1/8" 10
            // barcode heading
            //$this->pdf->rect(0,301,288,10,'D',array('all'=>$border_style));
            //$this->pdf->SetFont('helvetica', 'B', 13, '', false); // larger 10
            $this->pdf->setFont($fab, 'B', 13, '', false);
            $this->pdf->MultiCell( 290,300, 'USPS TRACKING #', 0, 'C', 0, 0, 0,298 , true,0, true, true, 23  );


            // white spece before bar code 1/32" 12
            //$this->pdf->rect(0,311,288,9,'D',array('all'=>$border_style));

            // bar code 1/32" 0.099218
            //$this->pdf->rect(20,320,248,54,'D',array('all'=>$border_style));
            
            //$checkcode = $item['barcode3'].'X';
            //$check=$this->checkmod10($checkcode);   
            //$bartext = chunk_split($item['barcode3'].$check, 4, ' '); //.$check;    
            $code = chr(241).$item['barcode1'].$item['barcode2'].chr(241).$item['barcode3'];

            /*
            $checkcode = $item['barcode3'].'X';
            $check=$this->checkmod10($checkcode);   
            $bartext = chunk_split($item['barcode3'].$check, 4, ' '); //.$check;    
            $code = chr(241).$item['barcode1'].$item['barcode2'].chr(241).$item['barcode3'].$check;
            */

            $bartext = chunk_split($item['barcode3'], 4, ' '); //.$check;    
            //$this->pdf->write1DBarcode($code, 'C128', 20,320,248,54, 1.12, $style=array(), $align='');
            $this->pdf->write1DBarcode($code, 'C128', 20,320,248,54, 1.12, $style=array(), $align='');
            //$this->pdf->write1DBarcode($code, 'C128B', 20,350,248,54, 1.12, $style=array(), $align='');
           // $this->pdf->write1DBarcode($code, 'C128C', 20,380,248,54, 1.12, $style=array(), $align='');
            
            
            // white spece after bar code 1/32" 0.099218
            //$this->pdf->rect(0,374,288,14,'D',array('all'=>$border_style));
            
            // barcode heading
            //$this->pdf->rect(0,388,288,11,'D',array('all'=>$border_style));
            //$this->pdf->SetFont('helvetica', 'B', 13, '', false); // larger 10
            $this->pdf->setFont($fab, 'B', 13, '', false);
            $this->pdf->MultiCell( 288,18, $bartext, 0, 'C', 0, 0,0,384, true,0, true, true, 0.396875  );

           // $this->pdf->MultiCell( 12.7,0.396875,'ddddddcc'.$check, 0, 'C', 0, 0,0,17.46, true,0, true, true, 0.396875  );


            // white spece 1/32" 0.099218
            //$this->pdf->rect(0,398,288,2.75,'D',array('all'=>$border_style));
            // thick link
            $this->pdf->rect(0,400.75,288,2.25,'F',array('all'=>$border_style),array(0,0,0));


            // MultiCell($w, $h, $txt, $border=0, $align='J', $fill=0, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0)

//}


            // Set Author
            $this->pdf->SetAuthor('Infinity');
            // Set Display Mode
            $this->pdf->SetDisplayMode('real', 'default');
            // Set Write text


            // Set Output and file name
           
             if ($this->pdf->Output( FCPATH.C_LABEL_PATH.$filename, 'F')!==false )
              {  
                $this->pdf->_destroy(TRUE);
                unset($this->pdf);
                return TRUE;
              }
             else 
              {  
                $this->pdf->_destroy(TRUE);
                unset($this->pdf);
                return FALSE;   
              }  
 }


public function checkmod10($ccode)
 {   
        $checkcode = str_split ( strrev($ccode), 1 ); 
        
        $odd = array();
        $even = array();
        foreach ($checkcode as $k => $v) {
            if ($k % 2 == 0) {
                if($k!=0)
                 $even[] = $v;
            }
            else {
                $odd[] = $v;
            }
        }

        $total = array_sum ( $odd );
        $total = $total*3;

        $total2 = array_sum ( $even );
        $result = $total+$total2;
        $mod = ceil($result/10)*10 - $result;    

        return $mod;    
 }

/*public function users_get()
 {

        
        // Users from a data store e.g. database
        $users = [
            ['id' => 0, 'name' => 'John', 'email' => 'john@example.com'],
            ['id' => 1, 'name' => 'Jim', 'email' => 'jim@example.com'],
        ];

        $id = $this->get( 'id' );

        if ( $id === null )
        {
            // Check if the users data store contains users
            if ( $users )
            {
                // Set the response and exit
                $this->response( $users, 200 );
            }
            else
            {
                // Set the response and exit
                $this->response( [
                    'status' => false,
                    'message' => 'No users were found'
                ], 404 );
            }
        }
        else
        {
            if ( array_key_exists( $id, $users ) )
            {
                $this->response( $users[$id], 200 );
            }
            else
            {
                $this->response( [
                    'status' => false,
                    'message' => 'No such user found'
                ], 404 );
            }
        }

 }*/
}