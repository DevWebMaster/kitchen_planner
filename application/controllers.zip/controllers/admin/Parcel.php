<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Parcel extends MY_Controller {

	public function __construct(){
		
		parent::__construct();
		auth_check(); // check login auth
		$this->rbac->check_module_access();
		$this->lang->load(array('admin/parcel.php'));
		$this->load->library('grocery_CRUD');
		//$this->load->model('admin/example_model', 'example_model');
		//$this->load->library('pagination'); // loaded codeigniter pagination liberary

		
	}

	public function index(){

		$this->load->helper('xcrud');
        $xcrud = xcrud_get_instance();
        $xcrud->table('gb_parcel_master');
        $xcrud->columns('parcel_id,	tracking_no, customer_id,  	weight_lbs, length_in,  height_in,rate_info , 	created_at ,parcel_status_id ');

        //$xcrud->subselect('length_in','{length_in} x {width_in} x {height_in} ');
        $xcrud->label('weight_lbs','Weight');	
        $xcrud->relation('customer_id','gb_customer_mast', 'id', 'name');

        $xcrud->unset_title();
        $xcrud->unset_add();
        $xcrud->unset_edit();
        $xcrud->unset_remove();
        $data['content'] = $xcrud->render();
		
		$this->load->view('admin/includes/_header');
		$this->load->view('admin/parcel/parcel_list',$data);
		$this->load->view('admin/includes/_footer');


	}
}
?>