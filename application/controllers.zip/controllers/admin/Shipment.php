<?php defined('BASEPATH') OR exit('No direct script access allowed');



class Shipment extends My_Controller {

	public function __construct(){

		parent::__construct();

		auth_check(); // check login auth

		$this->rbac->check_module_access();

		if($this->uri->segment(3) != '')
		$this->rbac->check_operation_access();

		$this->load->model('admin/shipment_model', 'shipment_model');
        $this->lang->load(array('admin/shipment.php'));
        $this->load->library('session');
        
        //$this->load->library('grocery_CRUD');
	}

	//--------------------------------------------------------------------------

	public function index(){

	   unset($_SESSION['shipment']);

        $this->load->helper('xcrud');
        $xcrud = xcrud_get_instance();
        $xcrud->table('gb_shipment_master');
        $xcrud->columns('code,name_en, facility_id, customer_id, shipment_status_id,customer_created_at,rec_status');
        $xcrud->label('code','Shipment Code');
        $xcrud->label('name_en','Shipment Name');
        $xcrud->label('facility_id','Facility');
        $xcrud->label('shipment_status_id','Shipment Status');
        $xcrud->label('customer_created_at','Created on');
        $xcrud->label('rec_status','Is Active?');
        $xcrud->label('customer_id','Customer');



        $xcrud->relation('facility_id','gb_facility', 'facility_id', 'facility_name');
        $xcrud->relation('customer_id','gb_customer_mast', 'id', 'name');
        $xcrud->relation('shipment_status_id','gb_parm_shipment_status', 'shipment_status_id', 'name_en');
        

        $attr_arr = array( 'target'=>'_self',     'data-selected'=>'0',   'data-shipment-id'=>"{shipment_id}",   
                           'class'=>"btn btn-default btn-sm cb", 'id'=>'cb{shipment_id}'  );
        $xcrud->button('#','Select Shipment','fa fa-square','Select     ',$attr_arr);


        $xcrud->unset_title();
        $xcrud->unset_add();
        $xcrud->unset_edit();
        $xcrud->unset_remove();

        $data['content'] = $xcrud->render();

        $this->load->view('admin/includes/_header');
        $this->load->view('admin/shipment/listing',$data);
        $this->load->view('admin/includes/_footer');
	}        

	//--------------------------------------------------------------------------
	public function filterSearch(){

                $data['customer_list'] = $this->shipment_model->get_all_customer_id();
                //$data['shipment_list'] = $this->shipment_model->get_all_shipment_id();
                $data['shipment_code_list'] = $this->get_shipment_code_list();
                
                if(isset($_POST['customer_name']) && isset($_POST['shipment_code']))
                {
                    $data['shipments'] = $this->shipment_model->get_all_shipments_search($_POST['customer_name'],$_POST['shipment_code']);
                    //$data['parcels'] = $this->shipment_model->get_parcels_by_shipment_id(6);
                }
                
		$this->load->view('admin/includes/_header', $data);
		$this->load->view('admin/shipment/general');
		$this->load->view('admin/includes/_footer');
	}       
        
	//--------------------------------------------------------------------------
	public function generate()
        {
            if(isset($_POST['selected_shipment_id']) && isset($_POST['trackno']))
            {
                $this->validateFacilityId($_POST['selected_shipment_id']);
                
                $excludedTracknoList =  explode("\r\n", $_POST['trackno']);
                
                $parcelList = array();
                foreach ($_POST['selected_shipment_id'] as $selected_shipment_id) {
                    array_push($parcelList,...$this->shipment_model->get_parcels_by_shipment_id($selected_shipment_id));
                    $facility_id = $this->shipment_model->get_facility_id_by_shipment_id($selected_shipment_id);
                }
                
                $this->validateTrackingNumber($parcelList, $excludedTracknoList);
                $excludedParcelIdList = $this->getParcelIdByTrackingNo($parcelList, $excludedTracknoList);
                $finalParcelIdList = $this->removeExcludedParcel($parcelList, $excludedTracknoList);
                $r = $this->shipment_model->update_manifest_status_ready($finalParcelIdList,$excludedParcelIdList);
                
                if($r)
                {
                    $data_manifest_master = array(
                            'manifest_id' => 0,
                            'facility_id' => $facility_id,
                            'schedule_at' => date('Y-m-d : h:m:s'),
                            'parcel_total' => count($finalParcelIdList),
                            'manifest_job_status_id' => 1,
                            'send_flag' => 0,
                            'send_log' => 0,
                            'created_at' => date('Y-m-d : h:m:s'),
                            'created_by' => $this->session->admin_id,
                            'updated_at' => date('Y-m-d : h:m:s'),
                            'updated_by' => $this->session->admin_id,
                    );
                    $data_manifest_master = $this->security->xss_clean($data_manifest_master);
                    $manifest_id = $this->shipment_model->add_manifest_job_master($data_manifest_master);
                    
                    if($manifest_id)
                    {
                        
                        foreach($parcelList as $parcel)
                        {
                            $data = array(
                                'manifest_id' => $manifest_id,
                                'parcel_id' => $parcel['parcel_id'],
                                'process_flag' => 0,
                                'created_at' => date('Y-m-d : h:m:s'),
                                'created_by' => $this->session->admin_id,
                                'updated_at' => date('Y-m-d : h:m:s'),
                                'updated_by' => $this->session->admin_id,
                            );
                            $data = $this->security->xss_clean($data);
                            $result = $this->shipment_model->add_manifest_job_detail($data);
                        }
                    }
                    
                    if($result)
                    {
                        $data_manifest_master['manifest_id'] = $manifest_id;
                        $this->session->set_userdata("job_manifest_info",$data_manifest_master);
                        //$this->session->set_flashdata('success', 'Job Manisfest Master has been added successfully!');
                        redirect(base_url('admin/shipment/success'));
                    }
                    
                }

            }

            
		$this->load->view('admin/includes/_header', $data);
		$this->load->view('admin/shipment/general');
		$this->load->view('admin/includes/_footer');
	}       
        
	//--------------------------------------------------------------------------
	public function checkbox_OnClick()
        {
            	//$data['customer'] = $this->invoice_model->customer_detail($id);
            if(isset($_POST['chkbox']))
            {
                $data['parcels'] = array();
                foreach ($_POST['chkbox'] as $chkbox) {
                    array_push($data['parcels'],...$this->shipment_model->get_parcels_by_shipment_id($chkbox));
                }
            }            
            echo json_encode($data['parcels']);
                        
//                $data['shipments'] = $this->shipment_model->get_all_shipments();
//                $data['customer_list'] = $this->shipment_model->get_all_customer_id();
//                $data['shipment_list'] = $this->shipment_model->get_all_shipment_id();
//                $data['shipment_code_list'] = $this->shipment_model->get_all_shipment_code();
//                
//                $data['parcels'] = $this->shipment_model->get_parcels_by_shipment_id(8);
                
                


                
//		$this->load->view('admin/includes/_header', $data);
//		$this->load->view('admin/shipment/general');
//		$this->load->view('admin/includes/_footer');
	} 
        
	//---------------------------------------------------------------
	public function errorInvalidTrackingNo(){

		$data['title'] = 'Invalid Tracking number found';
                $data['invalid_trackno'] = $this->session->userdata("invalidTrackno");
                
                $this->load->view('admin/includes/_header');
		$this->load->view('admin/shipment/invalid_trackno', $data);
		$this->load->view('admin/includes/_footer');
	}

        	//---------------------------------------------------------------
	public function errorInvalidFacilityId(){

		$data['title'] = 'Facility ID not match';
                $data['content'] = 'Cannot proceed. Selected shipment facility ID not match!!!';
                
                $this->load->view('admin/includes/_header');
		$this->load->view('admin/shipment/Fail', $data);
		$this->load->view('admin/includes/_footer');
	}

	public function success(){

		$data['title'] = 'Generated manifest job successfully';
                $data['job_manifest_info'] = $this->session->userdata("job_manifest_info");
                
                $this->load->view('admin/includes/_header');
		$this->load->view('admin/shipment/success', $data);
		$this->load->view('admin/includes/_footer');
	}
        
        private function validateTrackingNumber($parcelList, $excludedTracknoList)
        {
            $tracknoArr = array();
            $invalidTrackno = array();
            
            foreach($parcelList as $parcel)
            {
                array_push($tracknoArr, $parcel['tracking_no']);
            }

            foreach ($excludedTracknoList as $execTrackno)
            {
                if(!in_array($execTrackno, $tracknoArr))
                {
                    array_push($invalidTrackno, $execTrackno);
                }
            }
            
            if(count($invalidTrackno) > 0)
            {
                $this->session->set_userdata("invalidTrackno",$invalidTrackno);
                redirect(base_url('admin/shipment/errorInvalidTrackingNo'));

            }
            
        }

        private function validateFacilityId($selectedShipmentIdList)
        {
            $prevFacility_Id = -1;
            $currFacility_Id = -1;
            
            foreach($selectedShipmentIdList as $selectedShipmentId)
            {
                if($prevFacility_Id == -1)
                {
                    $prevFacility_Id = $this->shipment_model->get_facility_id_by_shipment_id($selectedShipmentId);
                }
                else 
                {
                    $currFacility_Id = $this->shipment_model->get_facility_id_by_shipment_id($selectedShipmentId);
                    
                    if($prevFacility_Id != $currFacility_Id)
                    {
                        redirect(base_url('admin/shipment/errorInvalidFacilityId'));
                    }
                    
                    $prevFacility_Id = $currFacility_Id;
                }
            }
        }
        
        private function removeExcludedParcel($parcelList, $excludedParcelList)
        {
            $finalParcelList = array();
            

            foreach ($parcelList as $parcel)
            {
                if(!in_array($parcel['tracking_no'], $excludedParcelList))
                {
                    array_push($finalParcelList, $parcel['parcel_id']);
                }
            }
            return $finalParcelList;
            
        }
        
        private function getParcelIdByTrackingNo($parcelList, $excludedTracknoList)
        {
            $execludedParcelIdArr = array();
            
            foreach($parcelList as $parcel)
            {
                if(in_array($parcel['tracking_no'], $excludedTracknoList))
                {
                    array_push($execludedParcelIdArr, $parcel['parcel_id']);
                }

            }

            return $execludedParcelIdArr;
        }

        private function get_shipment_code_list()
        {
            $finalList = array();
            
            $shipmentList = $this->shipment_model->get_all_shipments();
            
            foreach($shipmentList as $shipment)
            {
                $codeArr = array();
                
                $codeArr['shipment_id'] = $shipment['shipment_id'];
                $shipment_name = $shipment['name_en'];
                $warehouse_name = $this->shipment_model->get_warehouse_name_by_facility_id($shipment['facility_id']);
                $customer_name = $this->shipment_model->get_customer_name_by_customer_id($shipment['customer_id']);
                $parcel_count = $this->shipment_model->get_parcel_count_by_customer_id($shipment['customer_id']);
                $codeArr['info'] = $shipment_name." | ".$warehouse_name." | ".$customer_name." | ".$parcel_count;

                $codeList[] = $codeArr;
            }
            return $codeList;
        }

        public function add_session()
        {
            if( isset($_GET['item']) && $_GET['item']!="")
             {   
                $_SESSION['shipment'][$_GET['item']] = "x";
             }
             echo var_dump($_SESSION['shipment']);
        }

        public function remove_session()
        {
            if( isset($_GET['item']) && $_GET['item']!="")
             {   
                if(isset($_SESSION['shipment']) && count($_SESSION['shipment'])>0 )
                 {
                    unset($_SESSION['shipment'][$_GET['item']]);
                 } 
             }    

             echo var_dump($_SESSION['shipment']);
        }
}
?>	