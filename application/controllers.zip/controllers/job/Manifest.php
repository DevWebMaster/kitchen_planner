<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Manifest extends MY_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->database('default');
        $this->lang->load(array('job/job.php','job/manifest.php'));
        $this->load->model('job/job_model','job_model');
        $this->load->model('job/manifest_model','manifest_model');
        $this->load->model('admin/facility_model','facility_model');
        
        /*$this->load->model('api/shipment_model','shipment_model');
        */
    }




public function generate_file()
 {
    $job_code = "J001";
    $step = 5000;
    $start = 0;
    $isError = FALSE;
    $message = array();
    $rec = 0;
    $sep = '|';
    if( !$this->job_model->check_job($job_code) )
    {
        $isError = TRUE; 
        $message[] = trans('l_e_job_error');
    }
    
    $log_id = $this->job_model->log_job('start', $job_code, 0,'' );
    
    if( !$log_id )
    {
        $isError = TRUE; 
        $message[] = trans('l_e_job_error');
    }

    if(!$isError)  
    {
      $rtnarr = $this->manifest_model->get_manifest_master(); 
      // initialise data 
      foreach ($rtnarr as $fmtarr)
       {    
            $isError = false;
            $message = array();
            $file_arr=array();
            $manifest_id=$fmtarr['manifest_id']; 
            // mark master to processing 
            $data = array( 'run_at'=>date('Y-m-d H:i:s'), 'manifest_job_status_id'=>1); // change to 2 for production 
            $this->manifest_model->update_manifest_master($data,$manifest_id); 

            $rec_limit = 5;
            
            $rec_total = $this->manifest_model->get_parcel_count_by_manifest_id($manifest_id);    
            //$rec_total = $fmtarr['parcel_total'];
            $rec_count = 0;
            $i=0;

    /*******************************************************************************************************/       
    /*  while - loop start        */
    /*******************************************************************************************************/       
           while($rec_count<=$rec_total)
            {    


                $file_count = 0;
                $file_id = $this->manifest_model->create_manifest_file($manifest_id);             
                // get file name 
                $filename = $manifest_id.'-'.md5($file_id).'.txt';
                $path = FCPATH.C_MANIFEST_PATH;           
                $file_arr[] = $filename;
                $rtnarr_d = $this->manifest_model->get_manifest_detail($manifest_id);
                if(count($rtnarr_d)==0 )
                    break;
            

        /************************************************************************************************/
        /* create file  */            
        /************************************************************************************************/
                $handle = fopen($path.$filename, 'a');
                if($handle==false)
                {
                    $isError = true;
                    $message[] = trans('l_e_manisfest_file_error');
                    break;
                }

        /************************************************************************************************/
        /* create header H1  */            
        /************************************************************************************************/
                $h1='';
                $h1.='H1';  
                $h1.=$sep;
                
                $facility_info = $this->facility_model->get_facility_by_id($fmtarr['facility_id']);
                $additional_info = json_decode($facility_info['additional_info'],true );
                
                $usps_ai=$additional_info['usps']['usps_app_identifier'];    
                $usps_service_type=$additional_info['usps']['usps_service_type'];
                $usps_mid=$additional_info['usps']['usps_mid'];
                $system_serial=str_pad($file_id, 11, "0", STR_PAD_LEFT);
                
                //barcode_construct_code
                $usps_barcode_construct_code = $additional_info['usps']['barcode_construct_code'];  

                $h1.=$usps_ai;
                $h1.=$usps_service_type;
                $h1.=$usps_mid;
                $h1.=$system_serial; // system generate file id 
                // check digit 
                $temp = $usps_ai.$usps_service_type.$usps_mid.$system_serial.'X';
                $check_digit=$this->checkmod10($temp);
                $h1.=$check_digit;
                $h1.='1'; // electronic file type
                $h1.=$sep;

                //Date of Mailing
                $time_zone = $facility_info['time_zone'];
                $offset = $additional_info['usps']['manifest_creation_time_offset'];
                $facility_datetime = new DateTime("now", new DateTimeZone($time_zone) );
                $facility_datetime->modify('+'.$offset.' minutes');
                $date = $facility_datetime->format('Ymd');
                $h1.=$date;
                $h1.=$sep;

                $h1.=$facility_info['entry_type'];// entry facility type 
                $h1.=$sep;

                $h1.=$facility_info['entry_zipcode'];// entry facility zip code  
                $h1.=$sep;

                $h1.=$facility_info['entry_zipcode4'];// entry facility zip4   
                $h1.=$sep;

                $h1.='CN'; // Direct Entry Origin Country Code ?? where to get is it shipment 
                $h1.=$sep;

                $h1.='PKF'; // shipment fee code
                $h1.=$sep;

                $h1.='000000'; // extra shipment fee 
                $h1.=$sep;

                $h1.=str_pad("", 2," ", STR_PAD_RIGHT); // containerization indicator 2 empty  character
                $h1.=$sep;

                $h1.=$additional_info['usps']['usps_electronic_version'];  // USPS Electronic File Version Number
                $h1.=$sep;

                //get count date 
                $file_seq = $this->manifest_model->get_today_file_count();
                $datetime = new DateTime("now", new DateTimeZone($time_zone) );
                $h1.=$datetime->format('Ymd').str_pad($file_seq, 4, "0", STR_PAD_LEFT);    // transaction id // used latest count by date from minifest table  
                $h1.=$sep;

                $h1.=$additional_info['usps']['usps_vendor_code'];  // USPS vendor code 
                $h1.=$sep;

                $h1.=$additional_info['usps']['usps_vendor_product_version'];   //Software Vendor Product Version Number
                $h1.=$sep;

                $h1.='xxxxxxxxx';   //file record count  
                $h1.=$sep;
                
                $h1.=$additional_info['usps']['usps_master_mid'];   //mailler id  -  
                $h1.=$sep;

                $h1.=str_pad("", 2," ", STR_PAD_RIGHT);  //CRLF
                fwrite($handle, $h1."\n"); 
                $file_count++; // count header   
                

        /**************************************************************************************************/       
        /*  detail loop -  start        */
        /*************************************************************************************************/

            foreach ($rtnarr_d as $fmtarr_d)
             {    
                echo '<br>'.$fmtarr_d['parcel_id'].'<br>';

        /**************************************************************************************************/       
        /*  detail D1 -  start        */
        /*************************************************************************************************/       
                $d1='D1'; //rec id 
                $d1.=$sep;

                $d1.= $fmtarr_d['tracking_no'];    // tracking no 
                $d1.=$sep;

                // class of mail
                $carrier_info = json_decode($fmtarr_d['carrier_info'], true);
                $carrier_additional_info = json_decode($carrier_info['additional_info'], true);
                $d1.= $carrier_additional_info['mailclass']; //
                $d1.=$sep;

                $d1.= str_pad($carrier_info['service_type_code'], 4," ", STR_PAD_RIGHT);  // service type code
                $d1.=$sep;

                $d1.= str_pad($usps_barcode_construct_code, 4," ", STR_PAD_RIGHT);   // barcode_construct_code
                $d1.=$sep;

                $recv_info = json_decode( $fmtarr_d['recv_info'], true );
                $d1.= $recv_info['recv_zip_code'];
                $d1.=$sep;

                $d1.= $recv_info['recv_zip4_code'];
                $d1.=$sep;

                $d1.= $additional_info['usps']['dest_facility_type'];       // destination facility type
                $d1.=$sep;

                $d1.= $additional_info['usps']['dest_country_code'];    // destination country code
                $d1.=$sep;

                $d1.= str_pad('', 11," ", STR_PAD_LEFT);   // Foreign Postal Code 11 
                $d1.=$sep;

                $d1.= str_pad('', 5," ", STR_PAD_LEFT); // Carrier Route 
                $d1.=$sep;

                $d1.= "";//Logistics Manager Mailer ID 
                $d1.=$sep;

                $d1.= str_pad($additional_info['usps']['mail_owner_mailer_id'], 9," ", STR_PAD_RIGHT);//Mail Owner Mailer ID 
                $d1.=$sep;

                $d1.= "";                // Container ID 1
                $d1.=$sep;

                $d1.= "";                // Container type 1
                $d1.=$sep;

                $d1.= "";                // Container ID 2
                $d1.=$sep;

                $d1.= "";                // Container type 2
                $d1.=$sep;

                $d1.= "";                // Container ID 3
                $d1.=$sep;

                $d1.= "";                // Container type 3
                $d1.=$sep;

               
                $d1.=""; // mail_owner_cust_reg_crid
                $d1.=$sep;

                $d1.= str_pad($fmtarr_d['parcel_id'], 30," ", STR_PAD_RIGHT); // customer ref
                $d1.=$sep;

                $d1.= ""; //FAST  Reservation Number
                $d1.=$sep;

                $d1.= str_pad('0', 8,"0", STR_PAD_LEFT); //FAST scheduled induction date 
                $d1.=$sep;

                $d1.= str_pad('0', 6,"0", STR_PAD_LEFT); //FAST scheduled induction time 
                $d1.=$sep;

                $d1.= str_pad($additional_info['usps']['payment_acc_no'], 10," ", STR_PAD_LEFT);//payment account numnber
                $d1.=$sep;

                $d1.= str_pad($additional_info['usps']['payment_method'], 2," ", STR_PAD_LEFT);//method of payment 
                $d1.=$sep;

                $d1.= str_pad($additional_info['usps']['post_office_zip'], 5," ", STR_PAD_LEFT);//Post Office of Account ZIP Code
                $d1.=$sep;

                $d1.= str_pad("0", 5,"0", STR_PAD_LEFT); //Meter Serial Number
                $d1.=$sep;

                $d1.= str_pad("0", 6,"0", STR_PAD_LEFT); //Chargeback Code
                $d1.=$sep;

                $rate_info = json_decode($fmtarr_d['rate_info'],true) ;
                $rate = $rate_info[$fmtarr_d['customer_level_id']];
                $ratex = round($rate,2)*100; // round to 2 decimal then x 100
                $d1.= str_pad($ratex, 7,"0", STR_PAD_LEFT); //postage fees
                $d1.=$sep;

                $d1.= $carrier_additional_info['type']; // type 
                $d1.=$sep;

                $d1.= str_pad("", 22," ", STR_PAD_LEFT);//Customized Shipping Services Contracts (CSSC) Number
                $d1.=$sep;

                $d1.= str_pad("", 14," ", STR_PAD_LEFT);//Customized Shipping Services Contracts     
                $d1.=$sep;

                $d1.= $additional_info['usps']['unit_measure_code'];//Unit of Measure Code
                $d1.=$sep;

                $weight = round($fmtarr_d['weight_lbs'],4); 
                $weightx = $weight*10000; 
                $d1.= str_pad($weightx, 9,"0", STR_PAD_LEFT);//weight
                $d1.=$sep;

                $d1.= $additional_info['usps']['processing_cat']; // processing category
                $d1.=$sep;

                $d1.= $carrier_info['rate_ind']; // rate indicator
                $d1.=$sep;

                $d1.= $additional_info['usps']['dest_rate_ind']; // destination rate indicator
                $d1.=$sep;

                $d1.= str_pad($fmtarr_d['zone_id'], 2,"0", STR_PAD_LEFT); //Domestic Zone
                $d1.=$sep;

                $length = $fmtarr_d['length_in']; 
                $lengthx = round($length,2)*100;
                $d1.= str_pad($lengthx, 5,"0", STR_PAD_LEFT); //length
                $d1.=$sep;

                $width = $fmtarr_d['width_in']; 
                $widthx = round($width,2)*100;
                $d1.= str_pad($widthx, 5,"0", STR_PAD_LEFT); //width
                $d1.=$sep;
                
                $height = $fmtarr_d['height_in']; 
                $heightx = round($height,2)*100;
                $d1.= str_pad($heightx, 5,"0", STR_PAD_LEFT); //height
                $d1.=$sep;

                $dimension_weight = $fmtarr_d['dimension_weight'];
                $dimension_weightx = round($dimension_weight,2)*100;
                $d1.= str_pad($dimension_weightx, 6,"0", STR_PAD_LEFT); //dimension_weight
                $d1.=$sep;

                $d1.= str_pad($additional_info['usps']['extra_service_code_1st'], 3," ", STR_PAD_LEFT);//Extra Service Code
                $d1.=$sep;

                $d1.= str_pad($additional_info['usps']['extra_service_fee_1st'], 3," ", STR_PAD_LEFT);//Extra Service Fee 1st Service
                $d1.=$sep;
                
                $d1.= str_pad("", 3," ", STR_PAD_LEFT);    ////Extra Service Code2
                $d1.=$sep;

                $d1.= str_pad("0", 6,"0", STR_PAD_LEFT);   //Extra Service Fee 2nd Service
                $d1.=$sep;

                $d1.= str_pad("", 3," ", STR_PAD_LEFT);    ////Extra Service Code3
                $d1.=$sep;

                $d1.= str_pad("0", 6,"0", STR_PAD_LEFT);   //Extra Service Fee 3rd Service
                $d1.=$sep;

                $d1.= str_pad("", 3," ", STR_PAD_LEFT);    ////Extra Service Code 4
                $d1.=$sep;

                $d1.= str_pad("0", 6,"0", STR_PAD_LEFT);   //Extra Service Fee 4th Service
                $d1.=$sep;

                $d1.= str_pad("", 3," ", STR_PAD_LEFT);    ////Extra Service Code 5
                $d1.=$sep;

                $d1.= str_pad("0", 6,"0", STR_PAD_LEFT);   //Extra Service Fee 5th Service
                $d1.=$sep;

                $d1.= str_pad("0", 7,"0", STR_PAD_LEFT); // Value of Article
                $d1.=$sep;

                $d1.= str_pad("0", 6,"0", STR_PAD_LEFT); //COD Amount Due Sender
                $d1.=$sep;

                $d1.= str_pad("0", 4,"0", STR_PAD_LEFT); //Handling Charge
                $d1.=$sep;

                $d1.= str_pad("", 2," ", STR_PAD_LEFT); //Surcharge Type
                $d1.=$sep;

                $d1.= str_pad("0", 7,"0", STR_PAD_LEFT);  //Surcharge Amount
                $d1.=$sep;

                $d1.= str_pad("", 2," ", STR_PAD_LEFT);  //Discount Type
                $d1.=$sep;

                $d1.= str_pad("0", 7,"0", STR_PAD_LEFT); //Discount Amount
                $d1.=$sep;

                $d1.= str_pad("", 2," ", STR_PAD_LEFT);  //Non-Incidental Enclosure Rate Indicator
                $d1.=$sep;

                $d1.= str_pad("", 2," ", STR_PAD_LEFT);  //Non-Incidental Enclosure Class
                $d1.=$sep;

                $d1.= str_pad("0", 7,"0", STR_PAD_LEFT); //Non-Incidental Enclosure Postage
                $d1.=$sep;

                $d1.= str_pad("0", 9,"0", STR_PAD_LEFT); //Non-Incidental Enclosure Weight
                $d1.=$sep;

                $d1.= str_pad("", 1," ", STR_PAD_LEFT);//Non-Incidental Enclosure Processing Category
                $d1.=$sep;

                $d1.= str_pad($additional_info['usps']['postal_routing_barcode'], 1,"0", STR_PAD_LEFT);//Postal Routing Barcode
                $d1.=$sep;
                
                $d1.= str_pad("", 2," ", STR_PAD_LEFT);//Open and Distribute Contents Indicator
                $d1.=$sep;
                
                $d1.= "N"; //PO Box Indicator
                $d1.=$sep;
                
                $d1.= "Y"; //Waiver of Signature/ Carrier Release/ Merchant Override/ Customer Delivery Preference
                $d1.=$sep;

                $d1.= str_pad($additional_info['usps']['delivery_option_ind'], 1,"0", STR_PAD_LEFT); //Delivery Option Indicator
                $d1.=$sep;
                
                $d1.= str_pad("", 2," ", STR_PAD_LEFT);//Destination Delivery Point 2
                $d1.=$sep;

                $d1.= str_pad("", 1," ", STR_PAD_LEFT);//Removal Indicator 1
                $d1.=$sep;


                //**********************        *******************************************************/
                /**********************   add in original tracking number to parcel mast    *//////////////
                //**********************      bar code will depend on the orginial tracking       *******************************************************/
                $d1.= str_pad("", 2," ", STR_PAD_LEFT);//Tracking Indicator 2  - (73)
                $d1.=$sep;


                $d1.= str_pad("", 4," ", STR_PAD_LEFT);//Original Label Tracking Number Barcode Construct Code 4 ?????
                       // barcode_construct_code
                $d1.=$sep;

                $d1.= str_pad($fmtarr_d['tracking_no'], 34," ", STR_PAD_RIGHT); //Original Tracking Number
                $d1.=$sep;
                /***********************       *****************************************************/

                $d1.= str_pad($fmtarr_d['customer_id'], 30," ", STR_PAD_RIGHT);    //Customer Reference Number 2
                $d1.=$sep;

                $recv_info = json_decode($fmtarr_d['recv_info'],true);
                $d1.= str_pad($recv_info["recv_name"], 48," ", STR_PAD_RIGHT); //Recipient Name Destination
                $d1.=$sep;

                $d1.= str_pad($recv_info["recv_addr1"], 48," ", STR_PAD_RIGHT); //Delivery Address
                $d1.=$sep;

                $d1.= str_pad("", 3," ", STR_PAD_RIGHT); //Ancillary Service Endorsement
                $d1.=$sep;

                $d1.= str_pad("", 9," ", STR_PAD_RIGHT); //Address Service Participant Code
                $d1.=$sep;

                $d1.= str_pad("", 16," ", STR_PAD_RIGHT);    //Key Line
                $d1.=$sep;

                $d1.= strtoupper(str_pad($facility_info['rtn_addr1'], 48," ", STR_PAD_RIGHT));// return address
                $d1.=$sep;

                $d1.= strtoupper(str_pad($facility_info['rtn_addr_city'], 28," ", STR_PAD_RIGHT));// return city
                $d1.=$sep;

                $d1.= strtoupper(str_pad($facility_info['rtn_addr_state'], 2," ", STR_PAD_RIGHT));// return state
                $d1.=$sep;

                $d1.= str_pad($facility_info['rtn_addr_zip'], 5," ", STR_PAD_RIGHT);// return zip code
                $d1.=$sep;

                $d1.= "";// Logistic Mailing Facility CRID (86) 
                $d1.=$sep;

                $d1.= str_pad("", 2," ", STR_PAD_RIGHT);    //CRLF
                
                fwrite($handle, $d1."\n");
                $file_count++;

        /**************************************************************************************************/       
        /*  detail D1 -  end        */
        /*************************************************************************************************/       
        /**************************************************************************************************/       
        /*  detail D2 -  start        */
        /*************************************************************************************************/       
                $d2='D2';
                $d2.=$sep;
                
                $d2.= str_pad($fmtarr_d['tracking_no'], 34," ", STR_PAD_RIGHT);
                $d2.=$sep;
                
                $d2.= str_pad("", 96," ", STR_PAD_RIGHT);   //Filler
                $d2.=$sep;
                
                $d2.= strtoupper(str_pad($recv_info["recv_city"], 28," ", STR_PAD_RIGHT)); //receiver city
                $d2.=$sep;
                
                $d2.= strtoupper(str_pad($recv_info["recv_state"], 28," ", STR_PAD_RIGHT)); //receiver state
                $d2.=$sep;
                
                $d2.= strtoupper(str_pad($recv_info["recv_zip_code"], 5," ", STR_PAD_RIGHT)); //receiver zip 
                $d2.=$sep;
                
                $d2.= strtoupper(str_pad($recv_info["recv_zip4_code"], 4," ", STR_PAD_RIGHT)); //receiver zip4 
                $d2.=$sep;
                
                $d2.= str_pad($recv_info["recv_email"], 64," ", STR_PAD_RIGHT); //receiver email 
                $d2.=$sep;
                
                $d2.= str_pad($recv_info["recv_sms"], 64," ", STR_PAD_RIGHT); //receiver sms 
                $d2.=$sep;
                
                $sender_info = json_decode( $fmtarr_d['sender_info'], true );
                $d2.= strtoupper(str_pad($sender_info["send_name"], 48," ", STR_PAD_RIGHT)); //sender name 
                $d2.=$sep;
                
                $d2.= str_pad($sender_info["send_email"], 64," ", STR_PAD_RIGHT); //sender email 
                $d2.=$sep;
                
                $d2.= str_pad($sender_info["send_sms"], 64," ", STR_PAD_RIGHT); //sender sms 
                $d2.=$sep;
                
                $d2.= str_pad("", 2," ", STR_PAD_RIGHT); //CRLF 
        /****************************************************************************************************/        
                fwrite($handle, $d2."\n");
                $file_count++;
        /**************************************************************************************************/       
        /*  detail D2 -  end        */
        /*************************************************************************************************/       
        /**************************************************************************************************/       
        /*  update manifest detail -  start        */
        /*************************************************************************************************/       
                    
                $data = array( 'manifest_file_id'=>$file_id, 'process_flag'=>1 );
                $this->manifest_model->update_manifest_detail($data,$fmtarr_d['manifest_detail_id']);

        /**************************************************************************************************/       
        /*  update manifest detail -  end        */
        /*************************************************************************************************/       

                $i++; // count records 
                $rec_count++;
            /********************************************************************************************/
            /*  update back the detail     */
            /**********************************************************************************************/


            /*********************************************************************************************/    
            /*  check break file                                                                         */
            /*********************************************************************************************/
                if($i==$rec_limit) // break file if $rec_limit hits 
                 {
                    // reset   
                    $i=0;
                    $file_count = str_pad($file_count,'9','0',STR_PAD_LEFT);
                    fclose($handle); //close once
                    // replace file count to xxxxxxxx
                    $hh = str_replace('xxxxxxxxx',$file_count,$h1); 
                    // reopen the file and point the pointer on top     
                    $handle = fopen($path.$filename, 'r+');
                    fwrite($handle, $hh."\n");
                    fclose($handle); //close once 
                    continue;
                 }


            /*****************************************************************************************/
            /* Write header   */
            /*****************************************************************************************/
            } // end loop each 

                // close the file 
                fclose($handle); //close once

                $file_count = str_pad($file_count,'9','0',STR_PAD_LEFT);
                // replace file count to xxxxxxxx
                $hh = str_replace('xxxxxxxxx',$file_count,$h1); 
                // reopen the file and point the pointer on top     
                $handle = fopen($path.$filename, 'r+');
                fwrite($handle, $hh."\n");
                fclose($handle); //close once

        /**************************************************************************************************/       
        /*  detail loop -  end        */
        /*************************************************************************************************/

           }// end while  

        /**************************************************************************************************/       
        /*  update manifest master to update file and status - end         */
        /*************************************************************************************************/
            if($isError)           
                $data=array( 'error_log'=>json_encode($message), 'filename'=>json_encode($file_arr), 'manifest_job_status_id'=>5 );
            else    
                $data=array( 'filename'=>json_encode($file_arr), 'manifest_job_status_id'=>3 );
           
            $this->manifest_model->update_manifest_master($data,$manifest_id);

    /*******************************************************************************************************/       
    /*  while - loop end        */
    /*******************************************************************************************************/       

       }  // end of foreach loop 


    }

    $this->job_model->log_job('end', $job_code, $log_id,$message);

 }// close function 

public function checkmod10($ccode)
 {   
        $checkcode = str_split ( strrev($ccode), 1 ); 
        
        $odd = array();
        $even = array();
        foreach ($checkcode as $k => $v) {
            if ($k % 2 == 0) {
                if($k!=0)
                 $even[] = $v;
            }
            else {
                $odd[] = $v;
            }
        }

        $total = array_sum ( $odd );
        $total = $total*3;

        $total2 = array_sum ( $even );
        $result = $total+$total2;
        $mod = ceil($result/10)*10 - $result;    

        return $mod;    
 }

} 
?>